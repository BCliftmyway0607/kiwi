package informationsystem.privilege;

public abstract class Privilege {
    
    /* This method let sub-class override its own command function.
     * 
     * The parameter should be the command that user use to call specific function.
     * Dont need to be int type, could be anything like enum
     */
    
    //public abstract void privilegeListener(int command);
  
}