package informationsystem.privilege;

import informationsystem.data.*;
import informationsystem.data.Module;
import informationsystem.useraccount.Student;

/*  This class should include all the privilege function of:
 *  - Registrar
 */
public class RegistrarPrivilege extends Privilege {
    public static void checkReg(Student student) {
        
    }
    public static void checkCredit() {
        
    }
    public static void editModulesName(Module module,String newName) {
        module.setName(newName);
    }
    public static void editModuleLevelCode(Module module, String newCode) {
        module.setModuleCode(newCode);
    }
    public static void editModuleCredit(Module module, int newCredit) {
        module.setModuleCredit(newCredit);
    }
    public static void editModuleSeason(Module module, Module.Season newSeason) {
        module.setSeason(newSeason);
    }
    
    // Add/Remove Students
    public static void addStudent(Student.Title studentTitle,String studentSurname,String studentForename,Degree studentDegree,int studentRegNum,String studentEmail,String studentTutorName) {
        Student newStudent = new Student(studentTitle, studentSurname,studentForename,studentDegree,studentRegNum,studentEmail,studentTutorName);
        // Add this student to the Database
    }
    public static void removeStudent(Student student) {
        //Remove this guy from the Database
    }
    
    // Add/Drop Optional Modules
    public static void addModule(Student student, Module module) {
        //Will need to create a link between a student and a module
    }
    public static void dropModule(Student student, Module module) {
        // Will need to unlink student and module
    }
    
    
    // Function for checking all student modules are correct for their level of study
    
    
    /* Check Module credits are correct
    *public boolean checkModuleCredits(Student student);{
    *    if (student is undergrad);
    *        then check sum of student module credit is 120;
    *    if (student is postgrad);
    *        then check sum of student module credit is 180
    }
    */
    
    // Display the results of performing these
    
    
    /* Write a listener function, base on the parameter to call specific 
     * user action.
     * 
     * For example: 
     * privilegeListener(0); -> and 0 means editDegreeName()
     * then it will call editDegreeName;
     * 
  
    * The listener should include follow tasks:
    � add and remove students, linking them to their chosen degree and registering them for their
      initial period of study (subsequent periods are determined automatically);
      
    � add and drop optional modules on behalf of a student at a given period and level of study
      (compulsory modules are added automatically);
      
    � check that student registrations are complete and correct, ensuring that students are taking
      suitable approved modules for the level of study;
      
    � check that that the module credits taken by students in a period of study sum to the correct
      total (120 for undergraduates, 180 for postgraduates);
      
    � display the results of performing the above tasks, so that they can see that the system has
      responded appropriately to adding or deleting something.
    
    @Override
    public void privilegeListener(int command) {
        // TODO Auto-generated method stub
        
    }
    */
}
