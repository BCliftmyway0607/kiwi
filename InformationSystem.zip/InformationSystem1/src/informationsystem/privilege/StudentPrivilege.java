package informationsystem.privilege;

/*  This class should include all the privilege function of:
 *  - Student
 */
public class StudentPrivilege extends Privilege {
    
    /* Function that gets period and level of study and corresponding results
     *  and after shows the whole degree
     */
    
    /* Write a listener function, base on the parameter to call specific 
     * user action.
     * 
     * For example: 
     * privilegeListener(0); -> and 0 means editDegreeName()
     * then it will call editDegreeName;
     * 
    
    * The listener should include follow tasks:
        � view their own status, showing what they have achieved at each period and level of study,
        showing what the outcome was for each level and eventually for the whole degree.
        
    @Override
    public void privilegeListener(int command) {
        // TODO Auto-generated method stub
        
    }
    */

}
