package informationsystem.privilege;

import informationsystem.data.*;
import informationsystem.data.Module;
import informationsystem.data.Module.Season;
import informationsystem.useraccount.User;

/*  This class should include all the privilege function of:
 *  - Admin
 */
public class AdminPrivilege extends Privilege {
    
    // Add/Remove User Accounts/Password
    public static void addUser(String username, String password, User.Role role) {
        new User(username,password,role);
        //Add user to the database
    }
    
    public static void removeUser(User user) {
        //Remove user from database
    }
    

    // Add/Remove Departments
    public static void addDepartment(String departmentName, String departmentCode) {
        new Department(departmentName,departmentCode);
        //Add department to database
    }
    public static void removeDepartment(Department department) {
        //remove department from database
    }
    
    // Add/Remove Degrees
    public static void addDegree(String degreeName, String lName, Level degreeLevel, String degreeCode, boolean yearIn, Department department ) {
        new Degree(degreeName,lName,degreeLevel,degreeCode,yearIn,department);
        //Add degree to database
    }
    public static void removeDegree(Degree degree) {
        //remove degree from database
    }
    
    // Add/Remove Modules
    public static void addModule(String moduleName, String moduleCode, int moduleCredit,Season moduleSeason) {
        new Module(moduleName,moduleCode,moduleCredit,moduleSeason);
        //Add Module to database
    }
    public static void removeModule(Module module) {
        //remove Module from database
    }
    
    //For displaying the results interface should add something (maybe popup box?) to show it's been done
  
    
    /* Write a listener function, base on the parameter to call specific 
     * user action.
     * 
     * For example: 
     * privilegeListener(0); -> and 0 means editDegreeName()
     * then it will call editDegreeName;
     * 

    * The listener should include follow tasks
    Administrators perform the following tasks:
        � add and remove user accounts and passwords, granting suitable privileges to users to
          perform only the designated tasks for their role;
          
        � add and remove university departments from the system (as the university grows, more
          departments will be added);
          
        � add and remove degree courses, linking them to the one or many departments that teach
          the degree, indicating the lead department for the degree;
          
        � add and remove modules, linking them to the degrees and levels of study for which they are
          approved (stating whether core or not);
          
        � display the results of performing the above tasks, so that they can see that the system has
          responded appropriately to adding or deleting something.
    
    @Override  
    public void privilegeListener(int command) {
        // TODO Auto-generated method stub
        
    }
    */
}
