package informationsystem.privilege;

/*  This class should include all the privilege function of:
 *  - Teacher
 */
public class TeacherPrivilege extends Privilege {
    /* public static void add/updateGrade(Student student,Int grade) {
     *     function will decide if initial,resit or repeat year then add grade to student or update existing grade with new value
     * }
     */
    
    /* public boolean studentProgress(Student student) {
     *     Given a student function will calc the weighted mean grade and return true/false if a student can pass or not
     * }
     */
    
    // Function to decide progree,repeat,graduate or fail and doing the appropriate register
    
    /* static String obtainedClass(Student student){
     *     Using the grades from the second year and onward will calculate the weighted total
     *     then returns the class they have gotten as according to the chart
     * }
     */
    
    // Same function as the one for a student which is to view the whole status of the student
    
    

    /* Write a listener function, base on the parameter to call specific 
     * user action.
     * 
     * For example: 
     * privilegeListener(0); -> and 0 means editDegreeName()
     * then it will call editDegreeName;
     * 
    
    * The listener should include follow tasks:

      � add or update initial grades, resit grades, or repeat year grades for each student taking a
        module at a given period and level of study;
        
      � calculate the weighted mean grade for a period of study and determine whether a student
        may progress (according to the rules given above);
        
      � thereby cause a student to be registered for their next period of study, either progressing to
        the next level, or repeating a level, or graduating, or failing to progress;
        
      � calculate the overall degree result at the end of a student�s career and determine what kind
        of degree class they have obtained (according to the rules above);
        
      � view the status of any student, showing what that student has achieved at each period and
        level of study, showing what the outcome was for each level and eventually for the whole
        degree.

    
    @Override
    public void privilegeListener(int command) {
        // TODO Auto-generated method stub
        
    }
    */

}
