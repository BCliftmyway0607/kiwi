package informationsystem.sql;

import informationsystem.data.Degree;
import informationsystem.data.Department;
import informationsystem.data.Level;
import informationsystem.data.Module;
import informationsystem.useraccount.Student;
import informationsystem.useraccount.User;
import informationsystem.useraccount.student.ModuleSignUp;
import informationsystem.useraccount.student.RegistrationConfirm;

import java.sql.*;
import java.util.ArrayList;

public class RegistrarStatement {
    Student student;
    Module module;
    RegistrationConfirm registrationConfirm;
    Module credit;
    Module season;
    Degree degree;
    private static ResultSet rs = null;


    //For exeAddStudent and exeRemoveStudent
    public RegistrarStatement(String title, String surname, String forename, String tutor) {
        this.student = new Student(title,surname,forename,tutor);
    }
    
    // For remove Student
    // input registrationNumber
    public RegistrarStatement(int num) {
        this.student = new Student(num);
    }
    
    // For linking student to degree
    public RegistrarStatement(String degreeFullCode, int registNum) {
        this.degree = new Degree(degreeFullCode);
        this.student = new Student(registNum);
    }
    
    // For linking student to module
    public RegistrarStatement(int registNum, String moduleCode) {
        this.student = new Student(registNum);
        this.module = new Module(moduleCode);
    }
    
    public RegistrarStatement(String degreeFullCode) {
        this.degree = new Degree(degreeFullCode);
    }
    
    public RegistrarStatement() {}
    
    // title, Forename, Surname, DegreeCode, tutor, username
    // Missing check dup
     protected String exeAddStudent() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "INSERT INTO student "+""
                        + "(title, surname, forename, emailAdress, tutor, degreeFullCode)" + " "
                        + "values (?,?,?,?,?,0)";

                // Create PreparedStatement to swap keyword
                tempPrep = con.prepareStatement(stat);
                tempPrep.setString(1, student.getStudentTitle());
                tempPrep.setString(2, student.getStudentSurname());
                tempPrep.setString(3, student.getStudentForename());
                String names = student.getStudentForename().substring(0, 1) + student.getStudentSurname();
                /*
                 * Missing duplicate name check
                 */
                
                String email = names + "";
                tempPrep.setString(5, student.getStudentTutorName());
                // Only use executeUpdate() for INSERT, DELETE and UPDATE
                tempPrep.executeUpdate();
                // If success, return msg
                return "Added student: " + student.getStudentSurname();
            
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (rs != null)
                    rs.close();
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
        }
        return "Failed";
    }
    
    // Remove student
    // Unlink
    protected String exeRemoveStudent() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try{
            String stat = "DELETE FROM student WHERE registrationNum=?";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);

            tempPrep.setInt(1, student.getRegistNum());
            tempPrep.executeUpdate();
            return "Deleted student: " + student.getRegistNum();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (tempPrep != null)
                    tempPrep.close();
            } catch (Exception e) {
            }
        }
        return "Failed";
    }
    
    // Link student to degree 
    // Input: degreeFullCode, registrationNum
    // Unlink
    public String exeStudentToDegree() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "UPDATE student SET degreeFullCode=? WHERE registrationNum=?";

            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, degree.getDegreeFullCode());
            tempPrep.setInt(2, student.getRegistNum());
            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            tempPrep.executeUpdate();

            // If success, return msg
            return "Added module: " + module.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con!=null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return "Failed";
    }

    
    // Add Optional Module for student
    // Input: registrationNum, moduleCode
    public String exeAddModuleForStudent() throws SQLException {
        PreparedStatement tempPrep = null;
        PreparedStatement prep2 = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "SELECT studyID FROM student_to_study "+
                          "WHERE registrationNum=? ORDER BY label DESC";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);
            
            tempPrep.setInt(1, student.getRegistNum());
            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            ResultSet res = tempPrep.executeQuery();
            res.next();
            int currentID = res.getInt(1);
            String stat2 = "INSERT INTO study_moduleCollection (studyID, moduleCode) " +
                           "VALUES (?,?)";
            prep2 = con.prepareStatement(stat2);
            prep2.setInt(1, currentID);
            prep2.setString(2, module.getModuleCode());
            // If success, return msg
            return "Added module: " + module.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con!=null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return "Failed";
    }

    // Remove Optional Module for student
    

    /*
     * Non-Operation Functions
     * */
    
    // Unlink
    public ArrayList<String[]> getAllStudent(){
        Statement stmt = null;
        PreparedStatement prep = null;
        Connection con = getCon();
        ResultSet res2 = null;
        try {
            String str = "SELECT registrationNum, forename, surname, degreeFullCode FROM student";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(str);
            ArrayList<String[]> arrlist = new ArrayList<String[]>();
            while(res.next()) {
                String[] arrStr = new String[5];
                arrStr[0] = Integer.toString(res.getInt(1));
                arrStr[1] = res.getString(2);
                arrStr[2] = res.getString(3);
                arrStr[3] = res.getString(4);
                String str2 = "SELECT registration FROM student_to_study WHERE registrationNum=? ORDER BY label DESC";
                prep = con.prepareStatement(str2);
                prep.setInt(1, res.getInt(1));
                res2 = prep.executeQuery();
                res2.next();
                arrStr[4] = getRegistString(res2.getInt(1));
                arrlist.add(arrStr);
            }
            res.close();
            for(String[] p: arrlist) {
                for(String t: p)
                    System.out.print(t + " ");
                System.out.println("");
            }
            return arrlist;
        }catch(Exception ex) {
            ex.printStackTrace();
        }finally {
            try {
                if(con!=null)
                    con.close();
                if(stmt!=null)
                    stmt.close();
                if(prep!=null)
                    prep.close();
                if(res2!=null)
                    res2.close();
            }catch(Exception e) {
                
            }
        }
        return null;
    }
    
    // Unlink
    // Input: degreeFullCode
    public ArrayList<String[]> getNonCore() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "SELECT moduleCode FROM degree_to_module WHERE degreeFullCode=? AND core=0";
            ArrayList<String[]> list = new ArrayList<String[]>();
            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, degree.getDegreeFullCode());
            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            ResultSet res = tempPrep.executeQuery();
            while(res.next()) {
                String[] arr = {res.getString(1)};
                list.add(arr);
            }
            // If success, return msg
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con!=null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return null;
    }

    
    public static String getRegistString(int num) {
        switch(num){
        // Unregister    
        case 0:
            return "Unregister";
        // Unconfirm
        case 1:
            return "Unconfirmed";
        // Confirmed
        case 2:
            return "Confirmed";
        }
        return "error";
    }
    
    public static Connection getCon() {
        SQLhandler sql = new SQLhandler();
        try {
            return DriverManager.getConnection(sql.getUrl(), sql.getUser(), sql.getPass());
        } catch (SQLException e) {
            return null;
        }
    }
    public ArrayList<String[]> getModuleView() {
        Statement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT moduleName, moduleCode, credit, season FROM module";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);

            while (res.next()) {
                String[] acc = new String[4];
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = String.valueOf(res.getInt(3));
                if(Integer.parseInt(res.getString(4)) == 0) {
                    acc[3] = "Autumn";
                }
                else if(Integer.parseInt(res.getString(4)) ==1) {
                    acc[3] = "Spring";
                }
                else if(Integer.parseInt(res.getString(4)) == 2) {
                    acc[3] = "Summer";
                }
                else if (Integer.parseInt(res.getString(4)) == 3) {
                    acc[3] = "Whole Year";
                }
                list.add(acc);
            }
            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }
}
