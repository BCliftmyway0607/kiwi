package informationsystem.sql;
import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import informationsystem.useraccount.*;

public class LoginStatement{
    User acc;
    
    public LoginStatement(User acc) {
        this.acc = acc;
    }
    
    public int getLoginInfo() throws SQLException{
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try{
            
            String stat = "SELECT * FROM user WHERE username =?";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);

            // Swap keyword base on index
            tempPrep.setString(1, acc.getUserAccountName());
            
            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            ResultSet res = tempPrep.executeQuery();
            res.next();
            
            // If
            
            if(Encryption.validatePassword(acc.getUserAccountPassword(), res.getString(2))) {
                return res.getInt(3);
            }
            
            /*if(res.getString(2).equals(acc.getUserAccountPassword())){
                return res.getInt(3);
            }*/
            
            res.close();
        } catch(Exception ex){
            ex.printStackTrace();
            return 0;
        }finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return 0;
    }
    
    public static Connection getCon() {
        SQLhandler sql = new SQLhandler();
        try {
            return DriverManager.getConnection(sql.getUrl(),sql.getUser(),sql.getPass());
        } catch (SQLException e) {
            return null;
        }
    }
 }