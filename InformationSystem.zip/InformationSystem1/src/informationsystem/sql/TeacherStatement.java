package informationsystem.sql;

import java.util.*;
import informationsystem.data.Degree;
import informationsystem.data.Level;
import informationsystem.useraccount.Student;
import informationsystem.useraccount.student.Grade;
import informationsystem.useraccount.student.OverallGrade;
import informationsystem.useraccount.student.PeriodOfStudy;
import informationsystem.useraccount.student.Progression;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.ConsoleHandler;

public class TeacherStatement {
    Student student;
    Grade moduleGrade;
    PeriodOfStudy periodOfStudy;
    Level level;
    Module module;
    Progression progression;
    OverallGrade overallGrade;
    Degree degree;

    //For exeAddInitialGrade
    public TeacherStatement(Grade grade, Student student, PeriodOfStudy pos, Level level) {
        this.moduleGrade = grade;
        this.student = student;
        this.periodOfStudy = pos;
        this.level = level;
    }

    //For exeAddSecondGrade and exeAddRepeatYearGrade
    public TeacherStatement(double firstGrade, double secondGrade, double repeatYearGrade) {
        this.moduleGrade = new Grade(firstGrade, secondGrade, repeatYearGrade);

    }
    
    //For getStudentGrade
    public TeacherStatement(Student student) {
        this.student = student;
    }

    //add Initial grades
    public String exeAddGrade() throws SQLException {

        PreparedStatement prep1 = null;
        PreparedStatement prep2 = null;
        PreparedStatement prep3 = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat1 = "INSERT INTO student_to_module (firstGrade,registNum,periodOfStudy,level) values (?,?,?,?)";
            prep1 = con.prepareStatement(stat1);
            prep1.setDouble(1, moduleGrade.getFirstGrade());
            prep1.setInt(2, student.getRegistNum());
            prep1.setInt(3, periodOfStudy.getPeriodOfStudy());
            prep1.setInt(4, level.getLevelName());
            prep1.executeUpdate();
            // If success, return msg

            String stat2 = "INSERT INTO student_to_module (secondGrade,registNum,periodOfStudy,level) values (?,?,?,?)";
            prep2 = con.prepareStatement(stat2);
            prep2.setDouble(1, moduleGrade.getSecondGrade());
            prep2.setInt(2, student.getRegistNum());
            prep2.setInt(3, periodOfStudy.getPeriodOfStudy());
            prep2.setInt(4, level.getLevelName());
            prep2.executeUpdate();

            String stat3 = "INSERT INTO student_to_module (repeatGrade,registNum,periodOfStudy,level) values (?,?,?,?)";
            prep3 = con.prepareStatement(stat3);
            prep3.setDouble(1, moduleGrade.getRepeatYearGrade());
            prep3.setInt(2, student.getRegistNum());
            prep3.setInt(3, periodOfStudy.getPeriodOfStudy());
            prep3.setInt(4, level.getLevelName());
            prep3.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (prep1 != null)
                    prep1.close();
                if (prep2 != null)
                    prep2.close();
                if (prep3 != null)
                    prep3.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return "Failed";
    }


        public ArrayList<String[]> getStudentView() {
            Statement stmt = null;
            PreparedStatement tempPrep = null;
            Connection con = getCon();
            try {
                ArrayList<String[]> students = new ArrayList<String[]>();
                String q = "SELECT registrationNum, forename, surname, degreeFullCode FROM student";
                String gradEntryGet = "SELECT graduateEntry FROM degree WHERE degreeFullCode = ? ";
                String levelGet = "SELECT label FROM student_to_study WHERE registrationNum = ? ";
                stmt = con.createStatement();
                ResultSet res = stmt.executeQuery(q);

                while (res.next()) {
                    String[] acc = new String[6];
                    if (res.getInt(1) == 1)
                        acc[0] = "Mr";
                    else
                        acc[0] = "Ms";
                    acc[1] = res.getString(2);
                    acc[2] = res.getString(3);
                    acc[3] = res.getString(4);

                    // Getting the Graduate Entry and adding the appropriate under/postgrad to acc[4]
                    tempPrep = con.prepareStatement(gradEntryGet);
                    tempPrep.setString(1, res.getString(4));
                    ResultSet res2 = tempPrep.executeQuery();
                    String gradLevel = "Undergraduate";
                    if (res2.getInt(1) == 1)
                        gradLevel = "Postgraduate";
                    acc[4] = gradLevel;

                    //Getting the Label and adding to acc[5]
                    tempPrep = con.prepareStatement(levelGet);
                    tempPrep.setString(1, res.getString(1));
                    ResultSet res3 = tempPrep.executeQuery();
                    switch (res3.getInt(1)) {
                        case 1:
                            acc[5] = "A";
                            break;
                        case 2:
                            acc[5] = "B";
                            break;
                        case 3:
                            acc[5] = "C";
                            break;
                    }
                    students.add(acc);
                    res2.close();
                    res3.close();
                }
                res.close();

                return students;
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    if (stmt != null)
                        stmt.close();
                    if (con != null)
                        con.close();
                } catch (Exception e) {
                }

            }
            return null;
        }
        
        //Needs student object
        public ArrayList<String[]> getStudentGrades() {
            PreparedStatement tempPrep1 = null;
            PreparedStatement tempPrep2 = null;
            PreparedStatement tempPrep3 = null;
            Connection con = getCon();
            try {
                ArrayList<String[]> list = new ArrayList<String[]>();
                String first = "SELECT studyID FROM student_to_study WHERE registrationNum = ? ";
                String getGrades = "SELECT moduleCode, firstGrade, secondGrade, repeatGrade FROM student_to_module WHERE studyID = ? ";
                String getModuleName = "SELECT moduleName FROM module WHERE moduleCode = ? ";
                
                //Getting the StudyID
                tempPrep1 = con.prepareStatement(first);
                tempPrep1.setInt(1, student.getRegistNum());
                ResultSet res = tempPrep1.executeQuery();
                
                while (res.next()) {
                    
                
                    //Using the StudyID to get the grades and module code
                    tempPrep2 = con.prepareStatement(getGrades);
                    tempPrep2.setInt(1, res.getInt(1));
                    ResultSet res2 = tempPrep2.executeQuery();
                
                    //Creating the return set and putting in the grades
                    while (res2.next()) {
                        String[] info = new String[4];
                        if (String.valueOf(res2.getFloat(2)) != null)
                            info[1] = String.valueOf(res2.getFloat(2));
                        else
                            info[1] = null;
                        if (String.valueOf(res2.getFloat(3)) != null)
                            info[2] = String.valueOf(res2.getFloat(3));
                        else 
                            info[2] = null;
                        if (String.valueOf(res2.getFloat(4)) != null)
                            info[3] = String.valueOf(res2.getFloat(4));
                        else 
                            info[3] = null;
                    
                        //Getting and Adding the Module Name
                        tempPrep3 = con.prepareStatement(getModuleName);
                        tempPrep3.setString(1, res2.getString(1));
                        ResultSet res3 = tempPrep3.executeQuery();
                        info[0] = res3.getString(1);
                    
                        list.add(info); 
                        res3.close();
                    }
                
                    res2.close();
                   
                }
                res.close();

                return list;
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    if (con != null)
                        con.close();
                } catch (Exception e) {
                }

            }
            return null;
        }


        public static Connection getCon() {
            SQLhandler sql = new SQLhandler();
            try {
                return DriverManager.getConnection(sql.getUrl(), sql.getUser(), sql.getPass());
            } catch (SQLException e) {
                return null;
            }
        }
    }

