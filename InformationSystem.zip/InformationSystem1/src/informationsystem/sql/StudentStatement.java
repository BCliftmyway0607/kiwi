package informationsystem.sql;

import java.sql.*;
import java.util.ArrayList;

import informationsystem.useraccount.Student;

public class StudentStatement {
    public static Connection getCon() {
        SQLhandler sql = new SQLhandler();
        try {
            return DriverManager.getConnection(sql.getUrl(), sql.getUser(), sql.getPass());
        } catch (SQLException e) {
            return null;
        }
    }

    Connection con = getCon();

    public ArrayList<String[]> getStudentView() {
        Statement stmt = null;
        PreparedStatement tempPrep = null;

        try {
            ArrayList<String[]> students = new ArrayList<>();
            String q = "SELECT registrationNum, forename, surname, degreeFullCode FROM student";
            String gradEntryGet = "SELECT graduateEntry FROM degree WHERE degreeFullCode = ? ";
            String levelGet = "SELECT label FROM student_to_study WHERE registrationNum = ? ";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);
            while (res.next()) {
                String[] acc = new String[6];
                if (res.getInt(1) == 1)
                    acc[0] = "Mr";
                else
                    acc[0] = "Ms";
                acc[1] = res.getString(2);
                acc[2] = res.getString(3);
                acc[3] = res.getString(4);

                // Getting the Graduate Entry and adding the appropriate under/postgrad to acc[4]
                tempPrep = con.prepareStatement(gradEntryGet);
                tempPrep.setString(1, res.getString(4));
                ResultSet res2 = tempPrep.executeQuery();
                String gradLevel = "Undergraduate";
                if (res2.getInt(1) == 1)
                    gradLevel = "Postgraduate";
                acc[4] = gradLevel;

                //Getting the Label and adding to acc[5]
                tempPrep = con.prepareStatement(levelGet);
                tempPrep.setString(1, res.getString(1));
                ResultSet res3 = tempPrep.executeQuery();
                switch (res3.getInt(1)) {
                    case 1:
                        acc[5] = "A";
                        break;
                    case 2:
                        acc[5] = "B";
                        break;
                    case 3:
                        acc[5] = "C";
                        break;
                }
                students.add(acc);
                res2.close();
                res3.close();
            }
            res.close();

            return students;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return null;
    }
    
    public ArrayList<String[]> getStudentGrades(Student student) {
        PreparedStatement tempPrep1 = null;
        PreparedStatement tempPrep2 = null;
        PreparedStatement tempPrep3 = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String first = "SELECT studyID FROM student_to_study WHERE registrationNum = ? ";
            String getGrades = "SELECT moduleCode, firstGrade, secondGrade, repeatGrade FROM student_to_module WHERE studyID = ? ";
            String getModuleName = "SELECT moduleName FROM module WHERE moduleCode = ? ";
            
            //Getting the StudyID
            tempPrep1 = con.prepareStatement(first);
            tempPrep1.setInt(1, student.getRegistNum());
            ResultSet res = tempPrep1.executeQuery();
            
            while (res.next()) {
                
            
                //Using the StudyID to get the grades and module code
                tempPrep2 = con.prepareStatement(getGrades);
                tempPrep2.setInt(1, res.getInt(1));
                ResultSet res2 = tempPrep2.executeQuery();
            
                //Creating the return set and putting in the grades
                while (res2.next()) {
                    String[] info = new String[4];
                    if (String.valueOf(res2.getFloat(2)) != null)
                        info[1] = String.valueOf(res2.getFloat(2));
                    else
                        info[1] = null;
                    if (String.valueOf(res2.getFloat(3)) != null)
                        info[2] = String.valueOf(res2.getFloat(3));
                    else 
                        info[2] = null;
                    if (String.valueOf(res2.getFloat(4)) != null)
                        info[3] = String.valueOf(res2.getFloat(4));
                    else 
                        info[3] = null;
                
                    //Getting and Adding the Module Name
                    tempPrep3 = con.prepareStatement(getModuleName);
                    tempPrep3.setString(1, res2.getString(1));
                    ResultSet res3 = tempPrep3.executeQuery();
                    info[0] = res3.getString(1);
                
                    list.add(info); 
                    res3.close();
                }
            
                res2.close();
               
            }
            res.close();

            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return null;
    }
}



