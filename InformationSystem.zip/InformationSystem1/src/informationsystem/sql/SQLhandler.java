package informationsystem.sql;

import java.sql.*;

public class SQLhandler {
    private static String url = "jdbc:mysql://stusql.dcs.shef.ac.uk:3306/team002";
    private static String user = "team002", pass = "8e47e98d";
    private Connection connection;
    private Statement stmt;
    private ResultSet resultSet;

    public String getUrl() {return url;}
    public String getUser() {return user;}
    public String getPass() {return pass;}


    public SQLhandler() {
        connection = null;
        stmt = null;
    }
    private void execute(String query) {
        try{
            openConnection();
            openStatement();
            try {
                stmt.executeUpdate(query);
            } catch (Exception e) {
                e.printStackTrace();
            }
            finally {
                closeStatement();
                closeConnection();
            }

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
    }

    public Boolean executeBool(String query) {
        try {
            openConnection();
            openStatement();
            try {
                getStatement().executeUpdate(query);
            } finally {
                closeStatement();
                closeConnection();
            }
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException)
                return false;
            ex.printStackTrace();
        }
        return true;
    }




    public void insert(String table, String values) {
        execute("INSERT INTO " + table + " VALUES " + values + ";");
    }

    public void remove(String table, String conditions) {
        execute("DELETE FROM " + table + " WHERE " + conditions + ";");
    }

    protected void openResultQuery(String query) throws SQLException{
        resultSet = stmt.executeQuery(query);
    }

    protected void openConnection() throws SQLException {
        connection = DriverManager.getConnection(url, user, pass);
    }

    protected void openStatement() throws SQLException {
        stmt = connection.createStatement();
    }

    protected void closeConnection() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }

    protected void closeStatement() throws SQLException {
        if (stmt != null) {
            stmt.close();
        }
    }

    protected void closeResultSet() throws SQLException {
        if (resultSet != null) {
            resultSet.close();
        }
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    protected Connection getCon() throws SQLException {
        SQLhandler sql = new SQLhandler();
        try {
            return DriverManager.getConnection(sql.getUrl(), sql.getUser(), sql.getPass());
        } catch (SQLException e) {
            return null;
        }

    }

    protected Statement getStatement() {
        if (stmt != null) {
            return stmt;
        } else {
            return null;
        }
    }






}
