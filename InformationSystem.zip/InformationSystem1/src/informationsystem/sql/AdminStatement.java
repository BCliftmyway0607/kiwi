package informationsystem.sql;

import informationsystem.data.*;
import informationsystem.data.Module;
import informationsystem.useraccount.*;

import java.sql.*;
import java.util.*;

public class AdminStatement {
    User acc;
    Department department;
    Degree degree;
    Module module;
    String objectToDelete;
    private static ResultSet rs = null;

    public AdminStatement() {
    }

    // for delete and change role
    public AdminStatement(String name, int role) {
        this.acc = new User(name, role);
    }

    // for add role
    public AdminStatement(String name, String password, int role) {
        this.acc = new User(name, password, role);
    }

    // for add department
    public AdminStatement(String departmentName, String departmentCode) {
        this.department = new Department(departmentName, departmentCode);
    }

    // Add Degree
    public AdminStatement(String degreeName, String leadCode, boolean yearIn, int level) {
        this.degree = new Degree(degreeName, leadCode, yearIn, level);
    }

    // Remove Degree
    public AdminStatement(String degreeCode) {
        this.degree = new Degree(degreeCode);
    }

    // Add Module
    public AdminStatement(String moduleName, String moduleCode, int moduleCredit, int moduleSeason) {
        this.module = new Module(moduleName, moduleCode, moduleCredit, moduleSeason);
    }

    // Remove Module
    public AdminStatement(Module module) {
        this.module = module;
    }
    
    //For Unlinking Degree and Department
    public AdminStatement(Degree degree, Department department) {
        this.degree = degree;
        this.department = department;
    }

    /*
     * Operation Function
     */

    // Done
    public String exeAddAccount() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "INSERT INTO user (username, password, role) values (?,?,?)";
            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);
            if (tempPrep == null) {
                System.out.println("insertStmt==null : Can not Insert Statement object");

            } else {
                // Swap keyword base on index
                tempPrep.setString(1, acc.getUserAccountName());
                tempPrep.setString(2, acc.getUserAccountPassword());
                tempPrep.setInt(3, acc.getUserAccountRole());

                // Only use executeUpdate() for INSERT, DELETE and UPDATE
                tempPrep.executeUpdate();
                // If success, return msg
                return "Added user: " + acc.getUserAccountName();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (rs != null)
                    rs.close();
                if (tempPrep != null)
                    tempPrep.close();
                if (getCon() != null)
                    getCon().close();
            } catch (Exception e) {
            }
        }
        return "Failed";
    }



    // Done
    public String exeRemoveAccount() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            String stat = "DELETE FROM user WHERE username=?";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, acc.getUserAccountName());
            tempPrep.executeUpdate();
            return "Deleted user: " + acc.getUserAccountName();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    getCon().close();
            } catch (Exception e) {
            }
        }
        return "Failed";
    }

    // Done
    public String exeChangeRole() {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            String stat = "UPDATE user SET role =? WHERE username=?";
            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);
            tempPrep.setInt(1, acc.getUserAccountRole());
            tempPrep.setString(2, acc.getUserAccountName());
            tempPrep.executeUpdate();
            return "Update user: " + acc.getUserAccountName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    getCon().close();
            } catch (Exception e) {
            }
        }
        return "Failed";
    }

    // Done
    public String exeAddDepartment() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "INSERT INTO department" + " (departmentName,departmentCode)" + " values (?,?)";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);
            if (tempPrep == null) {
                System.out.println("insertStmt==null : Can not Insert Statement object");

            } else {
                // Swap keyword base on index
                tempPrep.setString(1, department.getName());
                tempPrep.setString(2, department.getCode());
                // Only use executeUpdate() for INSERT, DELETE and UPDATE
                tempPrep.executeUpdate();
                // If success, return msg
                return "Added department: " + department.getName();

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Unlink
    public String exeRemoveDepartment() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            String stat = "DELETE FROM department WHERE departmentName =?";
            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, department.getName());
            tempPrep.executeUpdate();
            return "Deleted department: " + department.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Done
    public String exeAddDegree() throws SQLException {
        PreparedStatement prep1 = null;
        PreparedStatement prep2 = null;
        PreparedStatement prep3 = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "INSERT INTO Degree"
                    + " (degreeFullCode, degreeName, leadCode, industry, graduateEntry)"
                    + " values (0,?,?,?,?)";

            // Create PreparedStatement to swap keyword
            prep1 = con.prepareStatement(stat);

            // Swap keyword base on index
            prep1.setString(1, degree.getName());
            prep1.setString(2, degree.getleadCode());
            int industry = degree.getyearInIndustry() ? 1 : 0;
            prep1.setInt(3, industry);
            prep1.setInt(4, degree.getLevel());

            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            prep1.executeUpdate();

            String stat2 = "SELECT degreeSerialCode FROM Degree WHERE degreeName = ?";
            prep2 = con.prepareStatement(stat2);
            prep2.setString(1, degree.getName());
            ResultSet res = prep2.executeQuery();
            res.next();
            String code = res.getString(1);
            String levelCode = "U";
            if (degree.getLevel() == 4)
                levelCode = "P";

            String industryCode = "";
            if (degree.getyearInIndustry())
                industryCode = "P";
            String degreeFullCode = degree.getleadCode() + levelCode + code + industryCode;
            String stat3 = "UPDATE Degree SET degreeFullCode =? WHERE degreeSerialCode = ?";
            prep3 = con.prepareStatement(stat3);
            prep3.setString(1, degreeFullCode);
            prep3.setString(2, code);
            prep3.executeUpdate();

            // If success, return msg
            return "Added degree: " + degree.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (prep1 != null)
                    prep1.close();
                if (prep2 != null)
                    prep2.close();
                if (prep3 != null)
                    prep3.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Unlink
    public String exeRemoveDegree() throws SQLException {
        PreparedStatement prep = null;
        Connection con = getCon();
        try {
            String stat = "DELETE FROM Degree WHERE degreeFullCode=?";
            prep = con.prepareStatement(stat);
            prep.setString(1, degree.getDegreeFullCode());
            prep.executeUpdate();
            return "Remove " + degree.getDegreeFullCode();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (prep != null)
                    prep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Unlink
    // Input: degreeFullCode, departmentCode
    public String exeLinkDegreeToDepartment() throws SQLException {
        PreparedStatement prep1 = null;
        PreparedStatement prep2 = null;
        Connection con = getCon();
        try {
            String stat = "SELECT EXISTS(SELECT departmentCode FROM department WHERE departmentCode=?)";
            prep1 = con.prepareStatement(stat);
            prep1.setString(1, department.getCode());
            ResultSet res = prep1.executeQuery();
            res.next();
            System.out.println(res.getInt(1));
            if(res.getInt(1) == 1) {
                String stat2 = "INSERT INTO degree_to_department (degreeFullCode, departmentCode) VALUES (?,?)";
                prep2 = con.prepareStatement(stat2);
                prep2.setString(1, degree.getDegreeFullCode());
                prep2.setString(2, department.getCode());
                prep2.executeUpdate();
                return "Success";
            }
            return "There is no target department: " + department.getCode();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (prep1 != null)
                    prep1.close();
                if(prep2 !=null)
                    prep2.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }
    
    //Unlinking using DegreeFullCode and DepartmentCode
    public String exeUnLinkDegreeToDepartment() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            String stat = "DELETE FROM degree_to_department WHERE degreeFullCode = ? AND departmentCode = ? ";
            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, degree.getDegreeFullCode());
            tempPrep.setString(2, department.getCode());
            tempPrep.executeUpdate();
            return "Unlinked " + degree.getName() + " AND " + department.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Unlinked
    public String exeAddModule() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            // Create base statement as String
            String stat = "INSERT INTO module" + " (moduleName,moduleCode,Credit,Season)"
                    + " values (?,?,?,?)";

            // Create PreparedStatement to swap keyword
            tempPrep = con.prepareStatement(stat);

            // Swap keyword base on index
            tempPrep.setString(1, module.getName());
            tempPrep.setString(2, module.getModuleCode());
            tempPrep.setInt(3, module.getModuleCredit());
            tempPrep.setInt(4, module.getSeason());
            //tempPrep.setString(4, module.getSeason()); // Unsure how to set Enums in here*

            // Only use executeUpdate() for INSERT, DELETE and UPDATE
            tempPrep.executeUpdate();

            // If success, return msg
            return "Added module: " + module.getName();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // No matter success or not, close the statement prevent issue
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }

        }
        return "Failed";
    }

    // Unlinked
    public String exeRemoveModule() throws SQLException {
        PreparedStatement tempPrep = null;
        Connection con = getCon();
        try {
            String stat = "DELETE FROM module WHERE moduleCode =?";
            tempPrep = con.prepareStatement(stat);
            tempPrep.setString(1, module.getModuleCode());
            tempPrep.executeUpdate();
            return "Deleted module: " + module.getModuleCode();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (tempPrep != null)
                    tempPrep.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    // Unlink
    // Input, moduleCode, degreeCode, isCore
    public String exeLinkModuleToDegree() throws SQLException {
        PreparedStatement prep1 = null;
        PreparedStatement prep2 = null;
        Connection con = getCon();
        try {
            String stat = "SELECT EXISTS(SELECT degreeFullCode FROM Degree WHERE degreeFullCode=?);";
            prep1 = con.prepareStatement(stat);
            prep1.setString(1, degree.getDegreeFullCode());
            ResultSet res = prep1.executeQuery();
            res.next();
            if(res.getInt(1) == 1) {
                String stat2 = "INSERT INTO degree_to_module (degreeFullCode, moduleCode, core) VALUES (?,?,?)";
                prep2 = con.prepareStatement(stat2);
                prep2.setString(1, degree.getDegreeFullCode());
                prep2.setString(2, module.getModuleCode());
                int core = module.getCore() ? 1:0;
                prep2.setInt(3, core);
                prep2.executeUpdate();
                return "Success";
            }
            return "There is no target degree: " + degree.getDegreeFullCode();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (prep1 != null)
                    prep1.close();
                if(prep2 != null)
                    prep2.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return "Failed";
    }

    /*
     * Non-Operation Queue
     */

    // Done
    public ArrayList<String[]> getAccountView() {
        Statement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT username, role FROM user";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);

            while (res.next()) {
                String[] acc = new String[2];
                acc[0] = res.getString(1);
                switch (res.getInt(2)) {
                case 1:
                    acc[1] = "ADMIN";
                    break;
                case 2:
                    acc[1] = "REGISTRAR";
                    break;
                case 3:
                    acc[1] = "TEACHER";
                    break;
                case 4:
                    acc[1] = "STUDENT";
                    break;
                }
                list.add(acc);
            }
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    // Done
    public ArrayList<String[]> getDepartmentView() {
        Statement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT departmentName, departmentCode FROM department";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);

            while (res.next()) {
                String[] acc = new String[2];
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                list.add(acc);
            }
            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    // Done
    public ArrayList<String[]> getDegreeView() {
        Statement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT degreeFullCode,graduateEntry, leadCode, industry FROM Degree";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);

            while (res.next()) {
                //System.out.println(res.getString(3));
                String[] acc = new String[4];
                acc[0] = res.getString(1);
                //acc[1] = res.getString(2);
                if (res.getInt(2) == 0)
                    acc[1] = "Undergraduate";
                else
                    acc[1] = "Postgraduate";
                acc[2] = res.getString(3);
                
                if (res.getString(4) == "1")
                    acc[3] = "No";
                else
                    acc[3] = "Yes";
                list.add(acc);
            }
            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    // Done
    public ArrayList<String[]> getDepartmentOfDegree(String degreeFullCode) {
        PreparedStatement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT departmentCode FROM degree_to_department " + "WHERE degreeFullCode=?";
            stmt = con.prepareStatement(q);
            stmt.setString(1, degreeFullCode);
            ResultSet res = stmt.executeQuery();

            String str = "SELECT departmentName, departmentCode FROM department " + "WHERE departmentCode=?";

            while (res.next()) {
                // Get departmentCode base on degreeCode
                stmt = con.prepareStatement(str);
                stmt.setString(1, res.getString(1));
                ResultSet res2 = stmt.executeQuery();
                while (res2.next()) {
                    // Use departmentCode execute second statement
                    String[] tempStr = new String[2];
                    tempStr[0] = res2.getString(1);
                    tempStr[1] = res2.getString(2);
                    
                    list.add(tempStr);
                }
                if (res2 != null)
                    res2.close();
            }

            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            System.out.println(list);
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    // Done
    public ArrayList<String[]> getModuleView() {
        Statement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT moduleName, moduleCode, credit, season FROM module";
            stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(q);

            while (res.next()) {
                String[] acc = new String[4];
                acc[0] = res.getString(1);
                acc[1] = res.getString(2);
                acc[2] = String.valueOf(res.getInt(3));
                if(Integer.parseInt(res.getString(4)) == 0) {
                    acc[3] = "Autumn";
                }
                else if(Integer.parseInt(res.getString(4)) ==1) {
                    acc[3] = "Spring";
                }
                else if(Integer.parseInt(res.getString(4)) == 2) {
                    acc[3] = "Summer";
                }
                else if (Integer.parseInt(res.getString(4)) == 3) {
                    acc[3] = "Whole Year";
                }
                list.add(acc);
            }
            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    // Done
    public ArrayList<String[]> getModuleOfDegree(String degreeFullCode) {
        PreparedStatement stmt = null;
        Connection con = getCon();
        try {
            ArrayList<String[]> list = new ArrayList<String[]>();
            String q = "SELECT moduleCode, core FROM degree_to_module" + "WHERE degreeFullCode=?";
            stmt = con.prepareStatement(q);
            stmt.setString(1, degreeFullCode);
            ResultSet res = stmt.executeQuery();

            String str = "SELECT moduleCode, credit FROM module" + "WHERE moduleCode = ?";

            while (res.next()) {
                // Get departmentCode base on degreeCode
                stmt = con.prepareStatement(str);
                stmt.setString(1, res.getString(1));
                String core = "FALSE";
                if (res.getInt(2) == 1)
                    core = "TRUE";
                ResultSet res2 = stmt.executeQuery();
                while (res2.next()) {
                    // Use departmentCode execute second statement
                    String[] tempStr = new String[3];
                    tempStr[0] = res2.getString(1);
                    tempStr[1] = core;
                    tempStr[2] = String.valueOf(res2.getInt(2));
                    list.add(tempStr);
                }
                if (res2 != null)
                    res2.close();
            }

            /*
             * For Testing: Print list for(String[] p: list) { System.out.print(p[0]+" ");
             * System.out.println(p[1]); }
             */
            res.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (Exception e) {
            }
            ;
        }
        return null;
    }

    public static Connection getCon() {
        SQLhandler sql = new SQLhandler();
        try {
            return DriverManager.getConnection(sql.getUrl(), sql.getUser(), sql.getPass());
        } catch (SQLException e) {
            return null;
        }
    }

}