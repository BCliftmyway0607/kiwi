package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.SwingPropertyChangeSupport;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import informationsystem.sql.AdminStatement;


public class AdminDegreeView extends JPanel{
    
    public static final String NAME = "AdminDegreeView";
    
    private DisplaySetup displaySetup;
    String[][] sample = new String[][] {{"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"},
        {"MAS148","Undergraduate","Level 1"},{"COM248","Postgraduate", "Level 2"},{"MAS378","Undergraduate","Level 3"},{"COM248","Postgraduate", "Level 2"}};
    String[] columnNames = {"Degree","Degree Level","Lead Dept.","Year in Industry"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    JTextField degreeName, leadDepartment,filterBox;
    String[] dataPass;
    JLabel degree, leadDept,filter,level,industryYr;

    String degreeID;
    private TableRowSorter sorter;
    
    AdminStatement ad = new AdminStatement();

    static ArrayList<String[]> myList;
    static ArrayList<String[]> allDepartments;
    static ArrayList<String> myDepartments;
    
    public AdminDegreeView(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 6;
        c.gridwidth = 6;
        
        myList = ad.getDegreeView();
        allDepartments = ad.getDepartmentView();
        myDepartments = new ArrayList<String>();
        
        for(int i = 0; i < allDepartments.size(); i++) {
            String[] temp = allDepartments.get(i);
            myDepartments.add(temp[0]);
        }
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,50,0,0);
        c.anchor = GridBagConstraints.NORTHWEST;
        JLabel title = new JLabel("Degree View");
        title.setFont(new Font("Verdana",Font.BOLD, 20));
        add(title,c);
        
        c.ipady = 10;
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,0);
        c.anchor = GridBagConstraints.NORTHEAST;
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(AdminHomepage.NAME);
            }
        }),c);
        
        c.ipady = 0;
        
        //c.fill = GridBagConstraints.HORIZONTAL;
        //c.anchor = GridBagConstraints.PAGE_START;
        //c.gridx = 0;        
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,150,0,0);
        c.anchor = GridBagConstraints.NORTHWEST;
        JTextField filterBox = new JTextField(20);
        filter = new JLabel("Filter:");
        add(filter,c);
        
        c.gridx = 2; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,300);
        c.anchor = GridBagConstraints.NORTH;
        add(filterBox,c);
        
        JTable table = new JTable(model);
        JTextField degreeName = new JTextField(20);
        JComboBox leadDepartment = new JComboBox(myDepartments.toArray());
        //JTextField leadDepartment = new JTextField(20);
        JComboBox degLevel = new JComboBox(new Object[] {"Undergraduate", "Postgraduate"});
        JComboBox yrInIndustry = new JComboBox(new Object[] {"NO", "YES"});
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<> (model);
        table.setRowSorter(sorter);
        tableSP.setPreferredSize(new Dimension(500,400));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < myList.size(); j++) {
            
            String[] temp = myList.get(j);
            
            model.addRow(new Object[] {temp[0],temp[1],temp[2],temp[3]});
            //model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2]});
        }

        //c.insets = new Insets(-50,0,0,0);
        c.gridx = 2; 
        c.gridy = 2;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,0,400);
        c.anchor = GridBagConstraints.CENTER;
        add(tableSP,c);
        
        //c.anchor = GridBagConstraints.EAST;
        c.gridx = 3; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.ipadx = 175;
        c.insets = new Insets(0,150,100,0);
        c.anchor = GridBagConstraints.SOUTHWEST;
        add(new JButton(new AbstractAction("Delete Degree") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //get the name of the Degree
                //AdminStatement admin = new AdminStatement(/*name*/);
                //admin.exeRemoveDegree();
                if(!degreeName.getText().isEmpty()) {
                    if (table.getSelectedRow() != -1) {
                        String degName = table.getValueAt(table.getSelectedRow(), 0).toString();
                        AdminStatement admin = new AdminStatement(degName);
                        try{
                            String result = admin.exeRemoveDegree();
                        if (result == "Failed") {
                            String[] s = {("Delete Degree " + table.getValueAt(table.getSelectedRow(),0)),"Failure"};
                            HistoryLog.addToHistory(s);
                        } 
                        else {
                            String[] s = {result,"Success"};
                            HistoryLog.addToHistory(s);
                        }
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    displaySetup.addAdminDegreeView();
                    displaySetup.showCard(AdminDegreeView.NAME);
                    }
                }
            }
        }),c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,150,50,0);
        c.ipadx = 90;
        c.anchor = GridBagConstraints.SOUTHWEST;
        add(new JButton(new AbstractAction("Show All or Link Departments") {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (table.getSelectedRow() != -1) {
                    int row = table.getSelectedRow();
                    
                    degreeID = table.getModel().getValueAt(row,0).toString();
                    DegreeDepartmentLink.setDegree(degreeID);
                   
                    displaySetup.addDegreeDepartmentLink();
                    displaySetup.showCard(DegreeDepartmentLink.NAME);
                }
            }
        }),c);
        
        c.ipadx = 0;
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,100,300);
        c.anchor = GridBagConstraints.EAST;
        degree = new JLabel("Degree Name");
        add(degree,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,100,50);
        c.anchor = GridBagConstraints.EAST;
        add(degreeName,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,300);
        c.anchor = GridBagConstraints.EAST;
        leadDept = new JLabel("Lead Department");
        add(leadDept,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,125);
        c.anchor = GridBagConstraints.EAST;
        add(leadDepartment,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,300);
        c.anchor = GridBagConstraints.EAST;
        level = new JLabel("Degree Level");
        add(level,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,125);
        c.anchor = GridBagConstraints.EAST;
        add(degLevel,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(175,0,0,300);
        c.anchor = GridBagConstraints.EAST;
        industryYr = new JLabel("Year In Industry");
        add(industryYr,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(175,0,0,150);
        c.anchor = GridBagConstraints.EAST;
        add(yrInIndustry,c);
        
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,150,200);
        c.anchor = GridBagConstraints.SOUTHEAST;
        add(new JButton(new AbstractAction("Add Degree") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //leadDepartment.getText();
                //leadDepartment.getSelectedItem();
                Boolean industry = yrInIndustry.getSelectedIndex() == 0;
                int mp = degLevel.getSelectedIndex();
                System.out.println(mp);
                AdminStatement admin = new AdminStatement(degreeName.getText(), leadDepartment.getSelectedItem().toString(), industry, mp);
                try {
                    String result = admin.exeAddDegree();
                    if (result == "Failed") {
                        String[] s = {("Delete Degree " + degreeName.getText()),"Failure"};
                        HistoryLog.addToHistory(s);
                    } 
                    else {
                        String[] s = {result,"Success"};
                        HistoryLog.addToHistory(s);
                    }

                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }    
                degreeName.setText(null);
                leadDepartment.setSelectedItem(0);//setText(null);
                degLevel.setSelectedItem("Undergraduate");
                yrInIndustry.setSelectedItem("NO");
                displaySetup.addAdminDegreeView();
                displaySetup.showCard(AdminDegreeView.NAME);
            }
        }),c);
     
        filterBox.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            public void search(String str) {
               if (str.length() == 0) {
                  sorter.setRowFilter(null);
               } else {
                  sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,0));
               }
            }
         });
    }
    
     
}
