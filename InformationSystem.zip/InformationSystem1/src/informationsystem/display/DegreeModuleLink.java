package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class DegreeModuleLink extends JPanel{
    
    public static final String NAME = "ModuleDegreeLink";
    
    private DisplaySetup displaySetup;
    String[][] sample = new String[][] {{"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"},
        {"MASU250","YES"},{"MADU3006", "NO"},{"COMU2109","NO"},{"COMu248", "YES"}};
    String[] columnNames = {"Degree","Core?","Study Period"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    JTextField degreeCode, filterBox;
    String[] dataPass;
    JLabel degCode, coreMod,filter;
    JTable table= new JTable(model);
    JComboBox coreModule;
    
    String modTitle;
    private TableRowSorter sorter;

    public static String temp = null;
    
    public DegreeModuleLink(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();        
        c.gridheight = 6;
        c.gridwidth = 6;
        
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,50,0,0);
        c.anchor = GridBagConstraints.NORTHWEST;    
        modTitle = "Degrees for Module: " + temp;
        JLabel title = new JLabel(modTitle);
        title.setFont(new Font("Verdana",Font.BOLD, 20));
        add(title,c);
        
        c.ipady = 10;
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,0);
        c.anchor = GridBagConstraints.NORTHEAST;
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(AdminModuleView.NAME);
            }
        }),c);
        
        c.ipady = 0;
        
        
        JTextField degreeCode = new JTextField(20);
        JComboBox coreModule = new JComboBox(new Object[] {"YES", "NO"});     
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,150,0,0);
        c.anchor = GridBagConstraints.NORTHWEST;
        JTextField filterBox = new JTextField(20);
        filter = new JLabel("Filter:");
        add(filter,c);
        
        c.gridx = 2; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,300);
        c.anchor = GridBagConstraints.NORTH;
        add(filterBox,c);
        
        //JTable table = new JTable(model);
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<> (model);
        table.setRowSorter(sorter);
        tableSP.setPreferredSize(new Dimension(300,400));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        
        for (int j =0 ; j < sample.length; j++) {
            model.addRow(new Object[] {sample[j][0],sample[j][1]});
        }
        

        //c.insets = new Insets(-50,0,0,0);
        c.gridx = 2; 
        c.gridy = 2;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,0,400);
        c.anchor = GridBagConstraints.CENTER;
        add(tableSP,c);
        
        //c.anchor = GridBagConstraints.EAST;
        c.gridx = 3; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.ipadx = 175;
        c.insets = new Insets(0,150,100,0);
        c.anchor = GridBagConstraints.SOUTHWEST;
        add(new JButton(new AbstractAction("Remove Degree") {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (table.getSelectedRow() != -1) {
                    String[] s = {("Remove Degree " + table.getValueAt(table.getSelectedRow(),0) + " From Module " + temp),"Success"};
                    HistoryLog.addToHistory(s);
                    model.removeRow(table.getSelectedRow());
                }
            }
        }),c);
        
        c.ipadx = 0;
        
        //c.anchor = GridBagConstraints.SOUTH;
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,300);
        c.anchor = GridBagConstraints.EAST;
        degCode = new JLabel("Degree Code");
        add(degCode,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,50);
        c.anchor = GridBagConstraints.EAST;
        add(degreeCode,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,300);
        c.anchor = GridBagConstraints.EAST;
        coreMod = new JLabel("Is Module Core");
        add(coreMod,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,150);
        c.anchor = GridBagConstraints.EAST;
        add(coreModule,c);
        
        c.gridx = 4; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,200,200);
        c.anchor = GridBagConstraints.SOUTHEAST;
        add(new JButton(new AbstractAction("Add Module") {

            @Override
            public void actionPerformed(ActionEvent e) {
                String[] s = {("Add Degree " + degreeCode.getText() + " To Module "+ temp),"Success"};
                HistoryLog.addToHistory(s);
                degreeCode.setText(null);
                coreModule.setSelectedItem("Yes");
            }
        }),c);
        
        filterBox.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            public void search(String str) {
               if (str.length() == 0) {
                  sorter.setRowFilter(null);
               } else {
                  sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,0));
               }
            }
         });
        
        
    }
    
    public static String getModule() {
        return temp;
    }
    
    public static void setModule(String s) {
        temp = s;
        System.out.println(temp);
    }
}
