package informationsystem.display;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StudentHomepage extends JPanel{

    public static final String NAME = "StudentHomepage";
    private DisplaySetup displaySetup;
    JLabel label;
    Dimension buttonDimension = new Dimension(200,100);
    static String username = null;
    
    public StudentHomepage(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 7;
        c.gridheight = 6;
        
        label = new JLabel("Welcome " + username);
        label.setFont(new Font("Verdana",Font.BOLD, 30));
        JButton registration = new JButton(new AbstractAction("Registration") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addStudentRegistration();
                displaySetup.showCard(StudentRegistration.NAME);
                //displaySetup.showCard(StudentView.NAME);
            }
        });
        JButton status = new JButton(new AbstractAction("Status") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addAccountView();
                displaySetup.showCard(AccountView.NAME);
                //displaySetup.showCard(StudentView.NAME);
            }
        });
        
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(20,0,0,20);
        c.weightx = .5;
        c.weighty = .5;
        c.gridx = 7;
        c.gridy = 0;
        add(new JButton(new AbstractAction("Log Out") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addLoginPanel();
                displaySetup.showCard(LoginPanel.NAME);
            }
        }),c);
        
        c.ipady = 0;
        c.anchor = GridBagConstraints.NORTH;
        c.gridy = 2;
        c.insets = new Insets(100,0,0,0);
        c.weightx = 1;
        c.weighty = 1;
        c.gridx = 4;
        add(label,c);
        
        c.ipady = 10;
        c.gridy = 2;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = .5;
        c.weighty = .5;
        c.gridx = 3;
        c.gridy= 6;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(0,100,50,0);
        registration.setPreferredSize(buttonDimension);
        add(registration,c);
        
        c.gridy = 2;
        c.anchor = GridBagConstraints.EAST;
        c.weightx = .5;
        c.weighty = .5;
        c.gridx = 5;
        c.gridy= 6;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(0,0,50,0);
        status.setPreferredSize(buttonDimension);
        add(status,c);

        
    }

    public static String getUsername() {
        return username;
    }
    
    public static void setUsername(String s) {
        username = s;
        System.out.println(username);
    }
}
