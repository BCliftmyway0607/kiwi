package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class HistoryLog extends JPanel{
    
    public static final String NAME = "HistoryLog";
    DisplaySetup displaySetup;
    static ArrayList<String[]> mylist = new ArrayList<String[]>();
    String[] columnNames = {"Action", "Success?"};
    static String accountType = null;
    
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    
    public HistoryLog(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        JLabel title = new JLabel("History Log");
        title.setFont(new Font("Verdana",Font.BOLD, 20));
        
        
        JTable table = new JTable(model);
        JTextField courseName = new JTextField(20);
        JTextField leadDepartment = new JTextField(20);
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableSP.setPreferredSize(new Dimension(600,400));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < mylist.size(); j++) {
            String[] temp = mylist.get(j);
            model.addRow(new Object[] {temp[0],temp[1]});
        }    
        
        c.weightx = .5;
        c.weighty = .5;
        c.anchor = GridBagConstraints.NORTH;
        
        add(title,c);
        
        c.anchor = GridBagConstraints.CENTER;
        
        add(tableSP,c);
        
        c.anchor = GridBagConstraints.NORTHEAST;
        c.ipady = 10;
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (accountType == "Admin") {
                    displaySetup.showCard(AdminHomepage.NAME);
                }
                else if (accountType == "Registrar") {
                    displaySetup.showCard(RegistrarHomepage.NAME);
                }
            }
        }),c);
    }
    
    
    public static void addToHistory(String[] s) {
        mylist.add(s);
    }
    
    public static void setAccountType(String s) {
        accountType = s;
    }
    
    
}
