package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AdminHomepage extends JPanel{

    public static final String NAME = "AdminHomepage";
    private DisplaySetup displaySetup;
    JLabel label;
    Dimension buttonDimension = new Dimension(200,100);
    public static String username = null;
    
    
    public AdminHomepage(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(20,20,0,0);
        add(new JButton(new AbstractAction("Log") {

            @Override
            public void actionPerformed(ActionEvent e) {
                HistoryLog.setAccountType("Admin");
                displaySetup.addHistoryLog();
                displaySetup.showCard(HistoryLog.NAME);
            }
        }),c);
        
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(20,0,0,20);
        add(new JButton(new AbstractAction("Log Out") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addLoginPanel();
                displaySetup.showCard(LoginPanel.NAME);
            }
        }),c);
        
        c.anchor = GridBagConstraints.NORTH;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.ipady = 0;
        c.insets = new Insets(100,250,0,0);
        label = new JLabel("Welcome " + username);
        label.setFont(new Font("Verdana",Font.BOLD, 30));
        add(label,c);
        
        c.anchor = GridBagConstraints.WEST;
        c.gridy = 2;
        c.insets = new Insets(0,100,0,0);
        
        JButton accounts = new JButton(new AbstractAction("Accounts") {

            @Override
            public void actionPerformed(ActionEvent e) {
                AdminAccountView.setTabValue(0);
                displaySetup.addAdminAccountView();
                displaySetup.showCard(AdminAccountView.NAME);
            }
        });
        accounts.setPreferredSize(buttonDimension);
        add(accounts,c);
        
        
        c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0,0,0,100);
        JButton departments = new JButton(new AbstractAction("Departments") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addAdminDepartmentView();
                displaySetup.showCard(AdminDepartmentView.NAME);
            }
        });
        departments.setPreferredSize(buttonDimension);
        add(departments,c);
        
        
        c.gridy = 3;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,100,0,0);
        JButton courses = new JButton(new AbstractAction("Degrees") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addAdminDegreeView();
                displaySetup.showCard(AdminDegreeView.NAME);
            }
        });
        courses.setPreferredSize(buttonDimension);
        add(courses,c);
        
        
        c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0,0,0,100);
        JButton modules = new JButton(new AbstractAction("Modules") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addAdminModuleView();
                displaySetup.showCard(AdminModuleView.NAME);
            }
        });
        modules.setPreferredSize(buttonDimension);
        add(modules,c);
        

        
        
    }
    
    public static String getUsername() {
        return username;
    }
    
    public static void setUsername(String s) {
        username = s;
        System.out.println(username);
    }
}
