package informationsystem.display;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class AccountView extends JPanel {
    public static final String NAME = "AccountView";
    private DisplaySetup displaySetup;
    
    Dimension tabDimension = new Dimension(900,600);
    static String studentLevel = null;
    
    public AccountView(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        this.setLayout(new GridLayout(1, 1));
    
        JTabbedPane tabbedPane = new JTabbedPane();
        SingleTab Overall = new SingleTab("Overall");
        Overall.setPreferredSize(tabDimension);
        tabbedPane.addTab("Overall", null, Overall, "Overall Results");

        
        FinishedLevelData LevelOne = new FinishedLevelData(displaySetup, "Level One");
        LevelOne.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level One", null, LevelOne, "Level One Results");

    
        FinishedLevelData LevelTwo = new FinishedLevelData(displaySetup, "Level Two");
        LevelTwo.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Two", null, LevelTwo, "Level Two Results");

    
        FinishedLevelData LevelThree = new FinishedLevelData(displaySetup, "Level Three");
        LevelThree.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Three", null, LevelThree, "Level Three Results");

        add(tabbedPane);
    
    }
    
    public static void setLevel(String s) {
        studentLevel = s;
    }
}

