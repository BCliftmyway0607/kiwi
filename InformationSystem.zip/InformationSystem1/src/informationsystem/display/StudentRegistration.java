package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import informationsystem.sql.AdminStatement;

public class StudentRegistration extends JPanel {

    public static final String NAME = "StudentRegistration";
    
    DisplaySetup displaySetup;
    
    String[] columnNames = {"Module","Core","Credits","Study Period"};
    
    String[][] sample = new String[][] {{"MAS148","Level 1","20"},{"COM248","Level 1","20"}};
   
    String[][] moduleChoices;
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    
    static DefaultTableModel choicesModel = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    int totalCredits = 0;
    static int maxCredits = 0;
    JLabel label, chosen, options, creditCount;
    //int totalCreditsChosed = 0;
        
    public StudentRegistration(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 8;
        c.gridwidth = 8;
        
        label = new JLabel("Module Registration");
        label.setFont(new Font("Verdana",Font.BOLD, 30));
        
        JTable table = new JTable(model);    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableSP.setPreferredSize(new Dimension(350,200));
        table.getTableHeader().setReorderingAllowed(false);
        
        JTable choices = new JTable(choicesModel);    
        JScrollPane choicesSP = new JScrollPane(choices);
        choices.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        choicesSP.setPreferredSize(new Dimension(350,200));
        choices.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
            //totalCredit = sum of core modules
            moduleChoices = new String[][] {{"MAS378","Level 1","10"},{"COM248","Level 1","10"},
                {"MAS148","Level 1","20"},{"COM248","Level 1","20"},{"MAS378","Level 1","10"},{"COM248","Level 1","10"}};//Allchoices
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }  
            moduleChoices = new String[][] {{"MAS378","Level 1","10"},{"COM248","Level 1","10"},
                {"MAS148","Level 1","20"},{"COM248","Level 1","20"},{"MAS378","Level 1","10"},{"COM248","Level 1","10"}};
        }
        
        for (int j =0 ; j < sample.length; j++) {
            int temp = Integer.parseInt(sample[j][2]);
            totalCredits += temp;
            model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2]});
        }
        
        if (choices.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                choicesModel.addColumn(columnNames[i]);
            }
        }
        
        if (choices.getRowCount() > 0) {
            for (int i = choices.getRowCount() - 1; i >= 0; i--) {
                choicesModel.removeRow(i);
            }
        }
        
        for (int j =0 ; j < moduleChoices.length; j++) {
            choicesModel.addRow(new Object[] {moduleChoices[j][0],moduleChoices[j][1],moduleChoices[j][2]});
        }
        
        chosen = new JLabel("Chosen Modules");
        chosen.setFont(new Font("Verdana",Font.BOLD, 20));
        options = new JLabel("Module Options");
        options.setFont(new Font("Verdana",Font.BOLD, 20));
        creditCount = new JLabel("Chosen Credits: " + Integer.toString(totalCredits));
        
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(20,20,0,0);
        add(label,c);
        
        /*c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5; 
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(StudentHomepage.NAME);
            }
        }),c);*/

        c.weightx = 1.5;
        c.weighty = 1.5;
        //c.ipady = 0;
        c.gridx = 1;
        c.gridy = 3;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,50,0,0);
        add(tableSP,c);
        
        c.weightx = 1.5;
        c.weighty = 1.5;
        c.gridx = 6;
        c.gridy = 3;
        c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0,0,0,50);
        add(choicesSP,c);
        
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(175,75,0,0);
        add(chosen,c);
        
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.SOUTHWEST;
        c.insets = new Insets(0,175,175,0);
        add(creditCount,c);
        
        c.gridx = 6;
        c.gridy = 2;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(175,0,0,100);
        add(options,c);
        
        c.gridx = 3;
        c.gridy = 6;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.insets = new Insets(0,0,150,200);
        add(new JButton(new AbstractAction("Add Module") {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (table.getSelectedRow() != -1) {
                    //remove from module choices and add to chosen modules, increase credits
            }
                displaySetup.showCard(StudentRegistration.NAME);
        }}),c);
        
        c.gridx = 4;
        c.gridy = 6;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.insets = new Insets(0,0,150,50);
        add(new JButton(new AbstractAction("Remove Module") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //displaySetup.showCard(RegistrarHomepage.NAME);
                int temp = 2;//number of core modules
                if (choices.getSelectedRow() > (temp-1)) {
                    //remove from chosen modules and add to module choices, decrease credits
                }
                displaySetup.showCard(StudentRegistration.NAME);
            }
        }),c);
        
        c.gridx = 4;
        c.gridy = 6;
        c.weightx = .5;
        c.weighty = .5; 
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.insets = new Insets(0,0,20,20);
        if(totalCredits == maxCredits) {
            add(new JButton(new AbstractAction("Complete") {

                @Override
                public void actionPerformed(ActionEvent e) {
                    //displaySetup.showCard(RegistrarHomepage.NAME);
                }
            }),c);}
    }      
}
