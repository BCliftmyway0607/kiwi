package informationsystem.display;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

import informationsystem.sql.AdminStatement;

public class EditAccount extends JPanel{
    
    JLabel accLevel;
    DisplaySetup displaySetup;
    
    public EditAccount(AdminAccountView aav, DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridheight = 4;
        c.gridwidth = 3;
        
        JComboBox accountLevel = new JComboBox(new Object[] {"Student", "Teacher", "Registrar", "Administrator"});
        accLevel = new JLabel("New Account Level");
        
        
        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,150,0,0);
        add(accLevel,c);
        
        c.anchor = GridBagConstraints.NORTHEAST;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(100,0,0,150);
        add(accountLevel,c);
        
        c.anchor = GridBagConstraints.CENTER;
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,0);
        add(new JButton(new AbstractAction("Update Account") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //AdminStatement admin = new AdminStatement(put the input for name,password,role here);
                //admin.exeAddAccount();
                if (aav.getTableRow() != -1) {
                    String accName = aav.getTableRowDataAt(aav.getTableRow(), 0).toString();
                    int role = 4;

                    switch(accountLevel.getSelectedItem().toString()) {
                    case "Student":
                        role = 4;
                        break;
                    case "Teacher":
                        role = 3;
                        break;
                    case "Registrar":
                        role = 2;
                        break;
                    case "Administrartor":
                        role = 1;
                        break;
                    }
                    AdminStatement admin = new AdminStatement(accName, role);
                    
                    String result = admin.exeChangeRole();
                    if (result == "Failed") {
                        String[] s = {("Update Account " + aav.getTableRowDataAt(aav.getTableRow(),0)),"Failure"};
                        HistoryLog.addToHistory(s);
                    } 
                    else {
                        String[] s = {result,"Success"};
                        HistoryLog.addToHistory(s);
                    }
                    
                    AdminAccountView.setTabValue(1);
                    displaySetup.addAdminAccountView();
                    displaySetup.showCard(AdminAccountView.NAME);

                }
            }
        }),c);
        
        c.anchor = GridBagConstraints.SOUTH;
        c.gridx = 2;
        c.gridy = 4;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,50,0);
        add(new JButton(new AbstractAction("Delete Account") {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (aav.getTableRow() != -1) {
                    String accName = aav.getTableRowDataAt(aav.getTableRow(), 0).toString();
                    AdminStatement admin = new AdminStatement(accName, 0);
                    try {
                        String result = admin.exeRemoveAccount();
                        if (result == "Failed") {
                            String[] s = {("Delete Account " + aav.getTableRowDataAt(aav.getTableRow(),0)),"Failure"};
                            HistoryLog.addToHistory(s);
                        } 
                        else {
                            String[] s = {result,"Success"};
                            HistoryLog.addToHistory(s);
                        }
                        displaySetup.addAdminAccountView();
                        displaySetup.showCard(AdminAccountView.NAME);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                    AdminAccountView.setTabValue(1);
                    displaySetup.addAdminAccountView();                    
                    displaySetup.showCard(AdminAccountView.NAME);
                    

                }
            }
        }),c);
    }
}
