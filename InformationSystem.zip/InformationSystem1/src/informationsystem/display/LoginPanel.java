package informationsystem.display;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.SQLException;

import javax.swing.*;

import informationsystem.sql.LoginStatement;
import informationsystem.useraccount.*;

public class LoginPanel extends JPanel implements ActionListener{
    
	public static final String NAME = "Login";
	private DisplaySetup displaySetup;
	
	JLabel userLabel = new JLabel("USERNAME");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField userTextField = new JTextField(20);
    JPasswordField passwordField = new JPasswordField(20);
    JCheckBox showPassword = new JCheckBox("Show Password");
    KeyListener keyListener = new KeyListener() {
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            	try {
                    successfulLogin();
                } catch (HeadlessException | SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }
            
        @Override
        public void keyReleased(KeyEvent arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void keyTyped(KeyEvent arg0) {

        }
    };
	
    public LoginPanel(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout()); 
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        add(userLabel,c);
        userTextField.setPreferredSize(new Dimension(100,20));
        userTextField.addKeyListener(keyListener);
        add(userTextField,c);
        c.gridy = 2;
        add(passwordLabel,c);
        passwordField.addKeyListener(keyListener);        
        add(passwordField,c);
        c.gridx = 1;
        c.gridy = 3;
        showPassword.addActionListener(this);
        add(showPassword,c);
        c.gridy = 4;
        add(new JButton(new AbstractAction("Login") {

            @Override
            public void actionPerformed(ActionEvent e) {
            	try {
                    successfulLogin();
                } catch (HeadlessException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }),c);
        
        
    }
    
    public void actionPerformed(ActionEvent e) {
        if (showPassword.isSelected()) {
            passwordField.setEchoChar((char) 0);
        } else {
            passwordField.setEchoChar('*');
        }
    }

    
    public void successfulLogin() throws HeadlessException, SQLException{
        String userText;
        String pwdText;
        userText = userTextField.getText();
        pwdText = passwordField.getText();
        User loginAccount = new User(userText, pwdText);
        LoginStatement loginStmt = new LoginStatement(loginAccount);
        int role = loginStmt.getLoginInfo();
        if (role!= 0) {

            switch(role) {
            case 1:
                AdminHomepage.setUsername(userText);
                displaySetup.addAdminHomepage();
                displaySetup.showCard(AdminHomepage.NAME);
                break;
            case 2:     
                RegistrarHomepage.setUsername(userText);
                displaySetup.addRegistrarHomepage();
                displaySetup.showCard(RegistrarHomepage.NAME);
                break;  
            case 3:
                TeacherHomepage.setUsername(userText);
                displaySetup.addTeacherHomepage();
                displaySetup.showCard(TeacherHomepage.NAME);
                break;
            case 4:     
                StudentHomepage.setUsername(userText);
                displaySetup.addStudentHomepage();
                displaySetup.showCard(StudentHomepage.NAME);
                break;   
            }
        } else {
            passwordField.setText(null);
            JOptionPane.showMessageDialog(this, "Invalid Username or Password");
       }
       
    }

}
