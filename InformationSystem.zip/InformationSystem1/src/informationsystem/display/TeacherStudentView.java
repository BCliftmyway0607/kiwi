package informationsystem.display;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class TeacherStudentView extends JPanel{

    public static final String NAME = "TeacherStudentView";
    
    private DisplaySetup displaySetup;
    JTabbedPane tabbedPane;
    
    static String student = null, studentLevel = null;
    Dimension tabDimension = new Dimension(900,500);
    static int firstTime = 0;
    
    
    public TeacherStudentView(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 6;
        c.gridheight = 5;
        
        
        tabbedPane = new JTabbedPane();
        if (tabbedPane.getTabCount() > 1) {tabbedPane.removeAll();}



        undergradGrades();        
        OverallDisplay overall = new OverallDisplay(displaySetup, studentLevel);
        overall.setPreferredSize(tabDimension);
        tabbedPane.addTab("Overall", null, overall, "Overall Results");
        //if(firstTime != 1) {panelReload();}
        
        c.ipady = 0;
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(0,0,0,0);
        add(tabbedPane,c);
          
            
        c.ipady = 10;
        c.gridx = 5;
        c.gridy = 6;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        add(new JButton(new AbstractAction("Back") {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                OverallDisplay.resetAverages();
                displaySetup.showCard(TeacherHomepage.NAME);
            }
        }),c);
    }
    
    public void panelReload() {
        displaySetup.addTeacherStudentView();
        //firstTime += 1;
        displaySetup.showCard(TeacherStudentView.NAME);
    }
    
    public void undergradGrades() {
        if(studentLevel == "Level 1") {
            addEditableLevelOne();
        }
        
        if(studentLevel == "Level 2") {
            addFixedLevelOne();
            addEditableLevelTwo();
        }
        
        if(studentLevel == "Level 3") {
            addFixedLevelOne();
            addFixedLevelTwo();
            addEditableLevelThree();
        }
        
        if(studentLevel == "Level 4") {
            addFixedLevelOne();
            addFixedLevelTwo();
            addFixedLevelThree();
            addEditableLevelFour();
        }
    }
    
    
    
    public void addFixedLevelOne() {
        FinishedLevelData levelOne = new FinishedLevelData(displaySetup, "Level One");
        levelOne.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level One", null, levelOne, "Level One Results");
    }
    
    public void addFixedLevelTwo() {
        FinishedLevelData levelTwo = new FinishedLevelData(displaySetup, "Level Two");
        levelTwo.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Two", null, levelTwo, "Level Two Results");
    }
    
    public void addFixedLevelThree() {
        FinishedLevelData levelThree = new FinishedLevelData(displaySetup, "Level Three");
        levelThree.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Three", null, levelThree, "Level Three Results");
    }
    
    public void addFixedLevelFour() {
        FinishedLevelData levelFour = new FinishedLevelData(displaySetup, "Level Four");
        levelFour.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Four", null, levelFour, "Level Four Results");
    }

    public void addEditableLevelOne() {
        LevelDataDisplay levelOne = new LevelDataDisplay(displaySetup, "Level One");
        levelOne.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level One", null, levelOne, "Level One Results");
    }
    
    public void addEditableLevelTwo() {
        LevelDataDisplay levelTwo = new LevelDataDisplay(displaySetup, "Level Two");
        levelTwo.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Two", null, levelTwo, "Level Two Results");
    }
    
    public void addEditableLevelThree() {
        LevelDataDisplay levelThree = new LevelDataDisplay(displaySetup, "Level Three");
        levelThree.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Three", null, levelThree, "Level Three Results");
    }
    
    public void addEditableLevelFour() {
        LevelDataDisplay levelFour = new LevelDataDisplay(displaySetup, "Level Four");
        levelFour.setPreferredSize(tabDimension);
        tabbedPane.addTab("Level Four", null, levelFour, "Level Four Results");
    }
    
    public static void setStudent(String s) {
        student = s;
    }
    
    public static void setFirstTime(int s) {
        firstTime = s;
    }
    
    public static void setStudentLevel(String s) {
        studentLevel = s;
    }
}
