package informationsystem.display;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class OverallDisplay extends JPanel {
    
    public static final String NAME = "PostgradDisplay";
    
    DisplaySetup displaySetup;
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
        
    static List<String> levelAverages = Arrays.asList(null,null,null,null);//new ArrayList<>();
    
    public OverallDisplay(final DisplaySetup displaySetup, String level) {
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 5;
        c.gridwidth = 6;
        
        
        if (level == "Level 1" || level == "Level 2" || level == "Level 3" || level == "Level 4") {        
            JLabel levelOne = new JLabel("Level 1 average " + levelAverages.get(0));
            levelOne.setFont(new Font("Verdana",Font.BOLD, 15));
            c.gridx = 3;
            c.weightx = .5;
            c.weighty = .5;
            c.anchor = GridBagConstraints.NORTH;
            c.insets = new Insets(50,0,0,0);
            add(levelOne,c); 
            if(level == "Level 2" || level == "Level 3" || level == "Level 4") {
                JLabel levelTwo = new JLabel("Level 2 average " + levelAverages.get(1));
                levelTwo.setFont(new Font("Verdana",Font.BOLD, 15));
                c.weightx = .5;
                c.weighty = .5;
                c.anchor = GridBagConstraints.NORTH;
                c.insets = new Insets(0,0,0,0);
                add(levelTwo,c); 
                if(level == "Level 3" || level == "Level 4") {
                    JLabel levelThree = new JLabel("Level 3 average " + levelAverages.get(2));
                    levelThree.setFont(new Font("Verdana",Font.BOLD, 15));
                    c.weightx = .5;
                    c.weighty = .5;
                    c.anchor = GridBagConstraints.NORTH;
                    c.insets = new Insets(0,0,0,0);
                    add(levelThree,c); 
                    /*
                     * if(courselength = 3years){new label with overall average and final result}
                     * */
                    if (level == "Level 4") {
                        JLabel levelFour = new JLabel("Level 4 average " + levelAverages.get(3));
                        levelFour.setFont(new Font("Verdana",Font.BOLD, 15));
                        c.weightx = .5;
                        c.weighty = .5;
                        c.anchor = GridBagConstraints.NORTH;
                        c.insets = new Insets(0,0,200,0);
                        add(levelFour,c);
                        /*
                         * if(courselength = 4years){new label with overall average and final result}
                         * */
                    }
                }
            }
        }
       
 
    }

    public static void setAverageAt(String s, int i) {
        levelAverages.set(i, s);
    }
    
    public static void resetAverages() {
        levelAverages = Arrays.asList(null,null,null,null);
    }
    
    public static void getAverageAt(int i) {
        System.out.println(levelAverages.get(i));
    }
}
