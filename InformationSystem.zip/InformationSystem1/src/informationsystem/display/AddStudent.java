package informationsystem.display;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddStudent extends JPanel {

    public static final String NAME = "AddStudent";
    
    JLabel forename, surname, degreeCode, title;
    
    DisplaySetup displaySetup;
    
    public AddStudent(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 6;
        c.gridwidth = 6;
        
        
        title = new JLabel("Add Student");
        title.setFont(new Font("Verdana",Font.BOLD, 30));
        
        forename = new JLabel("Enter Forename: ");
        surname = new JLabel("Enter Surname: ");
        degreeCode = new JLabel("Enter Degree Code: ");
        
        JTextField forenameField = new JTextField(20);
        JTextField surnameField = new JTextField(20);
        JTextField degreeCodeField = new JTextField(20);
        
        c.gridx = 3;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(50,0,0,0);
        add(title,c);
        
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(150,300,0,0);
        add(forename,c);
        
        c.gridx = 3;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(150,0,0,0);
        add(forenameField,c);
        
        c.gridx = 2;
        c.gridy = 3;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,300,0,0);
        add(surname,c);
        
        c.gridx = 3;
        c.gridy = 3;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0,0,0,400);
        add(surnameField,c);
        
        c.gridx = 2;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.SOUTHWEST;
        c.insets = new Insets(0,300,150,0);
        add(degreeCode,c);
        
        c.gridx = 3;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.insets = new Insets(0,0,150,380);
        add(degreeCodeField,c);
        
        c.gridx = 4;
        c.gridy = 5;
        c.weightx = .3;
        c.weighty = .3;
        c.ipady = 10;
        c.anchor = GridBagConstraints.SOUTH;
        c.insets = new Insets(0,0,50,0);
        add(new JButton(new AbstractAction("Submit") {

            @Override
            public void actionPerformed(ActionEvent e) {
                String studentName = forenameField.getText() + " " + surnameField.getText();
                String[] s = {("Add Student " + studentName),"Success"};
                HistoryLog.addToHistory(s);
                //displaySetup.addAdminAccountView();
                //displaySetup.showCard(AdminAccountView.NAME);
            }
        }),c);
        
        c.gridx = 6;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(RegistrarHomepage.NAME);
            }
        }),c);
    }
    
}
