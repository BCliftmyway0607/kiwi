package informationsystem.display;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class SingleTab extends JPanel {

    public SingleTab(String s) {
        add(new JLabel(s));
    }
}
