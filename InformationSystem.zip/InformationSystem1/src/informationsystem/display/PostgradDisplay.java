package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PostgradDisplay extends JPanel {
    
    public static final String NAME = "PostgradDisplay";
    
    DisplaySetup displaySetup;
    String[][] sample = new String[][] {{"12345","Tim","Peak","COMU2504"},{"12345","Tim","Peak","COMU2504"},{"12345","Tim","Peak","COMU2504"},{"12345","Tim","Peak","COMU2504"}};
    
    String[] columnNames = {"Module Code","Initial Grade","Resit Grade","Repeat Year Grade"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
        
    static String student = null;
    
    public PostgradDisplay(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 5;
        c.gridwidth = 6;

        JComboBox whichGrade = new JComboBox(new Object[] {"Initial Grade", "Resit Grade", "Repeat Year Grade"});
        JTextField gradeScore = new JTextField(8);
        JLabel gradeLabel = new JLabel("Grade");
        JTable table = new JTable(model);
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableSP.setPreferredSize(new Dimension(600,200));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 4) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < sample.length; j++) {
            model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2],sample[j][3]});
        }
        c.ipady = 10;
        c.gridx = 5;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(0,100,0,0);
        JLabel label = new JLabel("Module Results");
        label.setFont(new Font("Verdana",Font.BOLD, 30));
        add(label,c);
        
        c.ipady = 10;
        c.gridx = 5;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        add(new JButton(new AbstractAction("Back") {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                 displaySetup.showCard(TeacherHomepage.NAME);
            }
        }),c);   
        
        c.ipady = 0;
        
        c.gridx = 2; 
        c.gridy = 2;
        c.weightx = 2;
        c.weighty = 1;
        c.insets = new Insets(0,50,100,0);
        c.anchor = GridBagConstraints.WEST;
        add(tableSP,c);
        
        
        c.gridx = 3; 
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,100,200,0);
        c.anchor = GridBagConstraints.SOUTHWEST;
        add(whichGrade,c);
        
        c.gridx = 3; 
        c.gridy = 4;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,203,0);
        c.anchor = GridBagConstraints.SOUTH;
        add(gradeLabel,c);
        
        c.gridx = 4; 
        c.gridy = 4;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,150,200,0);
        c.anchor = GridBagConstraints.SOUTH;
        add(gradeScore,c);
        
        c.ipady = 10;
        c.gridx = 4; 
        c.gridy = 4;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,200,50);
        c.anchor = GridBagConstraints.SOUTHEAST;
        add(new JButton(new AbstractAction("Submit") {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (table.getSelectedRow() != -1) {
                    
                    gradeScore.setText(null);
                    whichGrade.setSelectedItem("Initial Grade");
                   
                }
            }
        }),c);
    }
    
    
    
    public static void setStudent(String s) {
        student = s;
    }
}
