package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class RegistrarHomepage extends JPanel{

    public static final String NAME = "RegistrarHomepage";
    private DisplaySetup displaySetup;
    JLabel label,filter;
    public static String username = null;
    String[][] sample = new String[][] {{"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"},
        {"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"},
        {"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"},
        {"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"},
        {"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"},
        {"12345","Tim","Peak","COMU2504", "Undergraduate","Level 1", "Complete"},{"24680","Jim","Daniels","MASP3470", "Postgraduate","Level 2", "Complete"},{"13579","Jane","Doe","COMU5404", "Undergraduate","Level 3", "Incomplete"}};
    String[] columnNames = {"Student ID","Forename","Surname","Degree Code", "Degree Level", "Current Level", "Registration Status"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
         
    private TableRowSorter sorter;
        
    public RegistrarHomepage(final DisplaySetup displaySetup) {
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 5;
        c.gridwidth = 6;
        //c.fill = GridBagConstraints.BOTH;
        
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(20,20,0,0);
        add(new JButton(new AbstractAction("Log") {

            @Override
            public void actionPerformed(ActionEvent e) {
                HistoryLog.setAccountType("Admin");
                displaySetup.addHistoryLog();
                displaySetup.showCard(HistoryLog.NAME);
            }
        }),c);
        
        c.ipady = 10;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(20,0,0,20);
        add(new JButton(new AbstractAction("Log Out") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addLoginPanel();
                displaySetup.showCard(LoginPanel.NAME);
            }
        }),c);

        c.anchor = GridBagConstraints.NORTH;
        c.gridx = 2;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.ipady = 0;
        c.insets = new Insets(100,250,0,0);
        label = new JLabel("Welcome " + username);
        label.setFont(new Font("Verdana",Font.BOLD, 30));
        
        JTextField filterBox = new JTextField(20);
        filter = new JLabel("Filter:");
        JComboBox combo = new JComboBox(new Object[] {"Student ID", "Forename", "Surname"});

        JTable table = new JTable(model);
        JTextField moduleName = new JTextField(20);
        JTextField moduleLevel = new JTextField(20);
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<> (model);
        table.setRowSorter(sorter);
        tableSP.setPreferredSize(new Dimension(800,400));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 6) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < sample.length; j++) {
            model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2],sample[j][3],sample[j][4],sample[j][5],sample[j][5]});
        }

        //c.insets = new Insets(-50,0,0,0);

        
        
        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(50,50,0,0);
        add(label,c);
        
        
        c.anchor = GridBagConstraints.NORTH;
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(100,0,0,50);
        add(filter,c);
        
        
        c.anchor = GridBagConstraints.NORTHEAST;
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(100,0,0,420);
        add(filterBox,c);
        add(combo,c);
        
        c.anchor = GridBagConstraints.NORTHEAST;
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(100,0,0,200);
        add(filterBox,c);
        
        c.anchor = GridBagConstraints.CENTER;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,0,0);
        add(tableSP,c);
        
        c.anchor = GridBagConstraints.SOUTHWEST;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,100,50,0);
        c.ipadx = 10;
        add(new JButton(new AbstractAction("Add Student") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addAddStudent();
                displaySetup.showCard(AddStudent.NAME);
            }
        }),c);
        
        
        c.anchor = GridBagConstraints.SOUTH;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,50,0);
        add(new JButton(new AbstractAction("Remove Student") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //get the name of the Module
                //AdminStatement admin = new AdminStatement(/*name*/);
                //admin.exeRemoveModule();
                if (table.getSelectedRow() != -1) {
                    
                    model.removeRow(table.getSelectedRow());
                }
            }
        }),c);
        
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,50,100);
        add(new JButton(new AbstractAction("Modules") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //get the name of the Module
                //AdminStatement admin = new AdminStatement(/*name*/);
                //admin.exeRemoveModule();
                if (table.getSelectedRow() != -1) {
                    
                   String name = (String) table.getValueAt(table.getSelectedRow(), 1) + " " + (String) table.getValueAt(table.getSelectedRow(), 2);
                   String level = (String) table.getValueAt(table.getSelectedRow(), 5);
                   String degreeLevel = (String) table.getValueAt(table.getSelectedRow(), 4);
                   StudentModulesView.setStudent(name);
                   StudentModulesView.setLevel(level);
                   StudentModulesView.setDegreeLevel(degreeLevel);
                   StudentModulesView.resetTotalCredits();
                   displaySetup.addStudentModulesDisplay();
                   displaySetup.showCard(StudentModulesView.NAME);
                   
                }
            }
        }),c);
        
        
        filterBox.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
               search(filterBox.getText());
            }
            public void search(String str) {
               if (str.length() == 0) {
                  sorter.setRowFilter(null);
               } else {
                   System.out.println(combo.getSelectedIndex());
                   if (combo.getSelectedIndex() == 0) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,0));}
                   else if (combo.getSelectedIndex() == 1) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,1));}
                   else if (combo.getSelectedIndex() == 2) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,2));}
            }}
         });
        
        combo.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String str = filterBox.getText();
                if (combo.getSelectedIndex() == 0) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,0));}
                else if (combo.getSelectedIndex() == 1) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,1));}
                else if (combo.getSelectedIndex() == 2) {sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,2));}
                else sorter.setRowFilter(null);
                
            }});
    }
    
    public static String getUsername() {
        return username;
    }
    
    public static void setUsername(String s) {
        username = s;
        System.out.println(username);
    }
}
