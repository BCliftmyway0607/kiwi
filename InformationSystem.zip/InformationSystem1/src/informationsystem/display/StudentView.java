package informationsystem.display;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.border.Border;

public class StudentView extends JPanel {

    public static final String NAME = "StudentView";
    private DisplaySetup displaySetup;
    //JLabel label;

    public StudentView(final DisplaySetup displaySetup) {

        this.displaySetup = displaySetup;
        //System.out.println(this.getLayout());
        //label = new JLabel(NAME);
        //label.setFont(new Font("Verdana",Font.PLAIN, 20));
        AccountView tabTest = new AccountView(displaySetup);
        //add(label, BorderLayout.PAGE_START);
        add(tabTest,BorderLayout.CENTER);
        //label.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    }
	
}
