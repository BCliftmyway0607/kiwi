package informationsystem.display;

import java.awt.CardLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class DisplaySetup extends JPanel{
	private static final int HEIGHT = 720;
	private static final int WIDTH = 1024;
	
	private CardLayout cardLayout = new CardLayout();
	private LoginPanel loginPanel;

    private AccountView accountView;
	private StudentHomepage studentHomepage;
	private TeacherHomepage teacherHomepage;
	private AdminHomepage adminHomepage;
	private RegistrarHomepage registrarHomepage;
    private DegreeModuleLink degreeModuleLink;
    private AdminDepartmentView adminDepartmentView;// = new AdminDepartmentView();
    private AdminModuleView adminModuleView;
    private AdminDegreeView adminDegreeView;// = new AdmindegreeView(this);
    private AdminAccountView adminAccountView;// = new AdminAccountView(this);
    private StudentModulesView studentModulesView;
    private AddStudent addStudent;
    private HistoryLog historyLog;
    private TeacherStudentView teacherStudentView;
    private PostgradDisplay postgradDisplay;
    private StudentRegistration studentRegistration;
	
    public static JPanel cards;
    
	public DisplaySetup() {
		setLayout(cardLayout);
		addLoginPanel();
		//add(accountView, AccountView.NAME);
		//add(studentHomepage, StudentHomepage.NAME);
		//add(teacherHomepage, TeacherHomepage.NAME);
		//add(adminHomepage, AdminHomepage.NAME);
		
		//add(adminDepartmentView, AdminDepartmentView.NAME);
		
		//add(admindegreeView, AdmindegreeView.NAME);
		//add(adminAccountView, AdminAccountView.NAME);
		//add(degreeModuleLink, DegreeModuleLink.NAME);
	}
	
    public void addLoginPanel() {
        LoginPanel loginPanel = new LoginPanel(this);
        add(loginPanel, LoginPanel.NAME);
    }
	
	public void addStudentHomepage() {
	    StudentHomepage studentHomepage = new StudentHomepage(this);
        add(studentHomepage, StudentHomepage.NAME);
    }
	
    public void addStudentRegistration() {
        StudentRegistration studentRegistration = new StudentRegistration(this);
        add(studentRegistration, StudentRegistration.NAME);
    }

    public void addPostgradDisplay() {
        PostgradDisplay postgradDisplay = new PostgradDisplay(this);
        add(postgradDisplay, PostgradDisplay.NAME);
    }
	
	public void addAccountView() {
	    AccountView accountView = new AccountView(this);
	    add(accountView, AccountView.NAME);
	}
	
    public void addTeacherHomepage() {
        TeacherHomepage teacherHomepage = new TeacherHomepage(this);
        add(teacherHomepage, TeacherHomepage.NAME);
    }	
    
    public void addTeacherStudentView() {
        TeacherStudentView teacherStudentView = new TeacherStudentView(this);
        add(teacherStudentView, TeacherStudentView.NAME);
    }

    public void addHistoryLog() {
        HistoryLog historyLog = new HistoryLog(this);
        add(historyLog, HistoryLog.NAME);
    }   
	
    public void addAdminHomepage() {
        AdminHomepage adminHomepage = new AdminHomepage(this);
        add(adminHomepage, AdminHomepage.NAME);
    }
    
    public void addRegistrarHomepage() {
        RegistrarHomepage registrarHomepage = new RegistrarHomepage(this);
        add(registrarHomepage, RegistrarHomepage.NAME);
    }
    
    public void addAdminModuleView() {
        AdminModuleView adminModuleView = new AdminModuleView(this);
        add(adminModuleView, AdminModuleView.NAME);
    }
    
    public void addAdminDegreeView() {
        AdminDegreeView admindegreeView = new AdminDegreeView(this);
        add(admindegreeView, AdminDegreeView.NAME);
    }
    
    public void addAdminDepartmentView() {
        AdminDepartmentView adminDepartmentView = new AdminDepartmentView(this);
        add(adminDepartmentView, AdminDepartmentView.NAME);
    }
    
    public void addAdminAccountView() {
        AdminAccountView adminAccountView = new AdminAccountView(this);
        add(adminAccountView, AdminAccountView.NAME);
    }
	
	public void addDegreeModuleLink() {
	    DegreeModuleLink degreeModuleLink = new DegreeModuleLink(this);
	    add(degreeModuleLink, DegreeModuleLink.NAME);
	}
	
    public void addDegreeDepartmentLink() {
        DegreeDepartmentLink degreeDepartmentLink = new DegreeDepartmentLink(this);
        add(degreeDepartmentLink, degreeDepartmentLink.NAME);
    }
    
    public void addStudentModulesDisplay() {
        StudentModulesView studentModulesView = new StudentModulesView(this);
        add(studentModulesView, StudentModulesView.NAME);
    }
    
    public void addAddStudent() {
        AddStudent addStudent = new AddStudent(this);
        add(addStudent, AddStudent.NAME);
    }
	
	public void showCard(String name) {
		cardLayout.show(this,  name);
	}

	private static void createAndShowGUI() {
		DisplaySetup mainDisplay = new DisplaySetup();
		
		JFrame frame = new JFrame("MainDisplay");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().add(mainDisplay);
		frame.pack();
		frame.setSize(WIDTH, HEIGHT);
		//reframe.setLocationByPlatform(true);
		frame.setVisible(true);
		frame.setResizable(false);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
}
