package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.SwingPropertyChangeSupport;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import informationsystem.sql.AdminStatement;

public class AdminAccountView extends JPanel{
    
    public static final String NAME = "AdminModuleView";
    
    private DisplaySetup displaySetup;
    
    /* Use code below to get AccountInfo
     * AdminStatement ad = new AdminStatement();
     * 
     * ad.getAccountView(); // This function will return an ArrayList
     */
    static int tabSelect = 0;
    /*String[][] sample = new String[][] {{"MAS148","Student"},{"COM248", "Teacher"},{"MAS378", "Admin"},{"COM248", "Registrar"},
        {"MAS148","Student"},{"COM248", "Teacher"},{"MAS378", "Admin"},{"COM248", "Registrar"},
        {"MAS148","Student"},{"COM248", "Teacher"},{"MAS372", "Admin"},{"COM248", "Registrar"},
        {"MAS148","Student"},{"COM248", "Teacher"},{"MAS378", "Admin"},{"COM248", "Registrar"},
        {"MAS148","Student"},{"COM248", "Teacher"},{"MAS378", "Admin"},{"COM248", "Registrar"},
        {"MAS148","Student"},{"COM248", "Teacher"},{"MAS278", "Admin"},{"COM248", "Registrar"},};*/
    String[] columnNames = {"Username", "AccountType"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }
    };
    private JTextField userName, passsword,filterBox;
    private String[] dataPass;
    private JLabel user, pass, accLevel,filter;
    private JComboBox accountLevel, filterType;
    private String moduleID;
    private TableRowSorter sorter;
    
    JTable table;

    Dimension tabDimension = new Dimension(600,300);
    
    static AdminStatement ad = new AdminStatement();
     
    static ArrayList<String[]> myList;
    
    public AdminAccountView(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 6;
        c.gridheight = 5;
        
        myList = ad.getAccountView();
        JLabel title = new JLabel("Account View");
        title.setFont(new Font("Verdana",Font.BOLD, 20));
        
        user = new JLabel("Username:");
        pass = new JLabel("Password:");
        accLevel = new JLabel("Role:");

        
        
        JTextField filterBox = new JTextField(20);
          
        
        
        filter = new JLabel("Filter:");

        
        table = new JTable(model);
        JTextField userName = new JTextField(20);
        JTextField password = new JTextField(20);
        JComboBox accountLevel = new JComboBox(new Object[] {"Student", "Teacher", "Registrar", "Administrator"});
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        sorter = new TableRowSorter<> (model);
        table.setRowSorter(sorter);
        tableSP.setPreferredSize(new Dimension(300,400));
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setResizingAllowed(false);
        
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < myList.size() ; j++) {//sample.length
            //model.addRow(new Object[] {sample[j][0],sample[j][1]});
            String[] temp = myList.get(j);
            model.addRow(new Object[] {temp[0],temp[1]});  
            //System.out.println(temp[0]);
            
        }

        
        
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(0,50,0,0);
        add(title,c);
        
        
        
        
        c.gridx = 5;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        c.ipady = 10; 
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(AdminHomepage.NAME);
            }
        }),c);
        
        c.ipady = 0;
        
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3;    
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,50,450,0);
        add(filter,c);
        
        
        c.gridx = 4;
        c.gridy = 2;
        c.weightx = .3;
        c.weighty = .3; 
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,100,450,0);
        add(filterBox,c);
        
        
        
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0,50,0,0);
        add(tableSP,c);
        
        
        /*c.gridx = 1;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        add(new JButton(new AbstractAction("Delete Account") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //get the username of the account
               // AdminStatement admin = new AdminStatement(username);
                //admin.exeRemoveAccount();
                if (table.getSelectedRow() != -1) {
                    
                    model.removeRow(table.getSelectedRow());
                }
            }
        }),c); */      
        
        
        JTabbedPane tabbedPane = new JTabbedPane();
        //SingleTab Overall = new SingleTab("Overall");
        AddAccount addAccount = new AddAccount(displaySetup);
        addAccount.setPreferredSize(tabDimension);
        tabbedPane.addTab("Add Account", null, addAccount, "Add An Account");

    
        //SingleTab LevelOne = new SingleTab("Level One");
        EditAccount editAccount = new EditAccount(this,displaySetup);
        editAccount.setPreferredSize(tabDimension);
        tabbedPane.addTab("Edit Account", null, editAccount, "Edit Account");
        tabbedPane.setSelectedIndex(tabSelect);


        c.gridx = 1;
        c.gridy = 4;
        c.weightx = 1;
        c.weighty = 1;
        c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0,0,0,50);
        add(tabbedPane,c);
        
        
       /* add(user,c);
        add(userName,c);

        add(pass,c);
        add(password,c);
        
        add(accLevel,c);
        add(accountLevel,c);

        add(new JButton(new AbstractAction("Add Account") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //AdminStatement admin = new AdminStatement(put the input for name,password,role here);
                //admin.exeAddAccount();
            }
        }),c);*/
        
        filterBox.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                search(filterBox.getText());
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                search(filterBox.getText());
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                search(filterBox.getText());
            }
            public void search(String str) {
                if (str.length() == 0) {
                    sorter.setRowFilter(null);
                } else {
                  sorter.setRowFilter(RowFilter.regexFilter("(?i)" + str,0));
                }
            }
         });
    }   

    public int getTableRow() {
        return table.getSelectedRow();
    }
    
    public static void setTabValue(int i) {
        tabSelect = i;
    }
     
    public Object getTableRowDataAt(int row, int column) {
        return table.getValueAt(row, column);
    }
}
