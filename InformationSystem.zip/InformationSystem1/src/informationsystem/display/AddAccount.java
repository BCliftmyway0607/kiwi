package informationsystem.display;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import informationsystem.sql.*;

public class AddAccount extends JPanel{
    
    private JLabel user, pass, accLevel;
    DisplaySetup displaySetup;
    
    public AddAccount(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridheight = 4;
        c.gridwidth = 3;
        //c.fill = GridBagConstraints.HORIZONTAL;
        
        
        JTextField userName = new JTextField(20);
        JTextField password = new JTextField(20);
        JComboBox accountLevel = new JComboBox(new Object[] {"Student", "Teacher", "Registrar", "Administrator"});
        
        user = new JLabel("Username:");
        pass = new JLabel("Password:");
        accLevel = new JLabel("Role:");
        
        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(50,100,0,0);
        add(user,c);
        
        c.anchor = GridBagConstraints.NORTHEAST;
        c.gridx = 2;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(50,0,0,100);
        add(userName,c);

        c.anchor = GridBagConstraints.WEST;
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,100,50,0);
        add(pass,c);
        
        c.anchor = GridBagConstraints.EAST;
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,50,100);
        add(password,c);

        c.anchor = GridBagConstraints.SOUTHWEST;
        c.gridx = 1;
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,100,120,0);
        add(accLevel,c);
        
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.gridx = 2;
        c.gridy = 3;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,120,150);
        add(accountLevel,c);

        c.anchor = GridBagConstraints.SOUTH;
        c.gridx = 1;
        c.gridy = 4;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,50,0);
        add(new JButton(new AbstractAction("Add Account") {

            @Override
            public void actionPerformed(ActionEvent e){
                if(!userName.getText().isEmpty() && !password.getText().isEmpty()) {
                    String accName = userName.getText();
                    //String accPass = password.getText();
                    try {
                        System.out.println();
                        String accPass = Encryption.generateStrongPasswordHash(password.getText());
                        int role = 0;
                        switch(accountLevel.getSelectedItem().toString()) { 
                            case "Student":
                                role = 4;
                                break;
                            case "Teacher":
                                role = 3;
                                break;
                            case "Registrar":
                                role = 2;
                                break;
                            case "Administrator":
                                role = 1;
                                break;
                        }
                    
                        AdminStatement ad = new AdminStatement(accName, accPass, role);
                        try {
                            String result = ad.exeAddAccount();
                            if (result == "Failed") {
                                String[] s = {("Add Account " + userName.getText()),"Failure"};
                                HistoryLog.addToHistory(s);
                            } 
                            else {
                                String[] s = {result,"Success"};
                                HistoryLog.addToHistory(s);
                            }
                            AdminAccountView.setTabValue(0);
                            displaySetup.addAdminAccountView();                    
                            displaySetup.showCard(AdminAccountView.NAME);
                        } catch (SQLException e1) {
                            e1.printStackTrace();
                        }
                    
                    } catch (NoSuchAlgorithmException e2) {
                        // TODO Auto-generated catch block
                        e2.printStackTrace();
                        JOptionPane.showMessageDialog(displaySetup, "Error Adding Account");
                    } catch (InvalidKeySpecException e2) {
                        // TODO Auto-generated catch block
                        e2.printStackTrace();
                        JOptionPane.showMessageDialog(displaySetup, "Error Adding Account");
                    }
            }}
        }),c);
    }
}
