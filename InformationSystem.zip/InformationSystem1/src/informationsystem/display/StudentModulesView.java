package informationsystem.display;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class StudentModulesView extends JPanel {
    
    public static final String NAME = "StudentModulesView";
    
    private DisplaySetup displaySetup;
    static String level = null, student = null, degreeLevel = null;
    static int totalCredit;
    String[][] sample = new String[][] {{"MAS148","Level 1","20"},{"COM248","Level 1","20"},{"MAS378","Level 1","10"},{"COM248","Level 1","10"},
        {"MAS148","Level 1","20"},{"COM248","Level 1","20"},{"MAS378","Level 1","10"},{"COM248","Level 1","10"}};
    String[] columnNames = {"Module","Core","Credits","Study Period"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    
    JLabel credits, title, modCode;

    public StudentModulesView(final DisplaySetup displaySetup){
        this.displaySetup = displaySetup;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 5;
        c.gridwidth = 5;
        
        
        JTable table = new JTable(model);    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableSP.setPreferredSize(new Dimension(300,200));
        table.getTableHeader().setReorderingAllowed(false);
        
        System.out.println(table.getColumnCount());
        if (table.getColumnCount() < 2) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < sample.length; j++) {
            int temp = Integer.parseInt(sample[j][2]);
            totalCredit += temp;
            model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2]});
        }
        
        title = new JLabel(level + " Modules for " + student + " (" + degreeLevel +")");
        title.setFont(new Font("Verdana",Font.BOLD, 30));
        String temp = Integer.toString(totalCredit);
        credits = new JLabel("Total Credit Value: " + temp);
        modCode = new JLabel("Module Code:");
        JTextField moduleCode = new JTextField(20);
        
        c.gridx = 2;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(0,0,300,0);
        add(title,c);
        
        c.gridx = 2;
        c.gridy = 2;
        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(0,0,0,0);
        add(tableSP,c);
        
        c.gridx = 3;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(225,150,0,0);
        add(credits,c);
        
        c.gridx = 2;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(400,0,0,150);
        add(modCode,c);
        
        c.gridx = 3;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.insets = new Insets(400,200,0,0);
        add(moduleCode,c);
        
        c.gridx = 4;
        c.gridy = 4;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.SOUTHEAST;
        c.insets = new Insets(0,0,85,350);
        c.ipady = 10;
        add(new JButton(new AbstractAction("Add Module") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //displaySetup.showCard(RegistrarHomepage.NAME);
                /*ANY MODULE ADDED WILL NOT BE CORE*/
            }
        }),c);
        
        c.gridx = 3;
        c.gridy = 5;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.SOUTHWEST;
        c.insets = new Insets(0,550,175,0);
        c.ipady = 10;
        add(new JButton(new AbstractAction("Remove Module") {

            @Override
            public void actionPerformed(ActionEvent e) {
                //displaySetup.showCard(RegistrarHomepage.NAME);
            }
        }),c);
        
        c.gridx = 3;
        c.gridy = 5;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.SOUTHWEST;
        c.insets = new Insets(0,550,25,0);
        c.ipady = 10;
        add(new JButton(new AbstractAction("Complete Registration") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.addRegistrarHomepage();
                displaySetup.showCard(RegistrarHomepage.NAME);
            }
        }),c);
        
        c.gridx = 5;
        c.gridy = 1;
        c.weightx = .3;
        c.weighty = .3;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.insets = new Insets(0,0,0,0);
        c.ipady = 10;
        add(new JButton(new AbstractAction("Back") {

            @Override
            public void actionPerformed(ActionEvent e) {
                displaySetup.showCard(RegistrarHomepage.NAME);
            }
        }),c);
    }
    
    public static void setLevel(String s) {
        level = s;
    }
    
    public static String getLevel() {
        return level;
    }
    
    public static void setStudent(String s) {
        student = s;
    }
    
    public static String getStudent() {
        return student;
    }
    
    public static void setDegreeLevel(String s) {
        degreeLevel = s;
    }
    
    public static String getDegreeLevel() {
        return degreeLevel;
    }
    
    public static void resetTotalCredits() {
        totalCredit = 0;
    }
    
    public static int getTotalCredits() {
        return totalCredit;
    }
}