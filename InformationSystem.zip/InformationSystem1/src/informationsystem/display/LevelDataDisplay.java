package informationsystem.display;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class LevelDataDisplay extends JPanel {
    
    public static final String NAME = "LevelDataDisplay";
    
    DisplaySetup displaySetup;
    String[][] sample = new String[][] {{"12345","20","80","Peak","COMU2504"},{"12345","20","70","Peak","COMU2504"},{"12345","20","80","Peak","COMU2504"},{"12345","20","70","Peak","COMU2504"},{"12345","20","80","Peak","COMU2504"},{"12345","20","70","Peak","COMU2504"}};
    
    String[] columnNames = {"Module Code","Credit","Initial Grade","Resit Grade","Repeat Year Grade"};
    static DefaultTableModel model = new DefaultTableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }};
    
    float average;
    
    public LevelDataDisplay(final DisplaySetup displaySetup, String s) {
        average = 0;
        this.displaySetup = displaySetup;
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridheight = 5;
        c.gridwidth = 6;

        JComboBox whichGrade = new JComboBox(new Object[] {"Initial Grade", "Resit Grade", "Repeat Year Grade"});
        JTextField gradeScore = new JTextField(8);
        JLabel gradeLabel = new JLabel("Grade");
        JTable table = new JTable(model);
    
        JScrollPane tableSP = new JScrollPane(table);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableSP.setPreferredSize(new Dimension(600,400));
        table.getTableHeader().setReorderingAllowed(false);
        
        if (table.getColumnCount() < 4) {
            for (int i =0 ; i < columnNames.length; i++) {
                model.addColumn(columnNames[i]);
            }
        }
        
        if (table.getRowCount() > 0) {
            for (int i = table.getRowCount() - 1; i >= 0; i--) {
                model.removeRow(i);
            }
        }
        
        for (int j =0 ; j < sample.length; j++) {
            //System.out.println(Float.parseFloat(sample[j][1])/120);
            
            average += (Float.parseFloat(sample[j][1]))*Float.parseFloat(sample[j][2]);
            System.out.println(average);
            model.addRow(new Object[] {sample[j][0],sample[j][1],sample[j][2],sample[j][3],sample[j][4]});
        }
        average = average/120;
        System.out.println(average);
        if(s == "Level One") {OverallDisplay.setAverageAt(Float.toString(average), 0); OverallDisplay.getAverageAt(0);}
        else if(s == "Level Two") {OverallDisplay.setAverageAt(Float.toString(average), 1);}
        else if(s == "Level Three") {OverallDisplay.setAverageAt(Float.toString(average), 2);}
        else if(s == "Level Four") {OverallDisplay.setAverageAt(Float.toString(average), 3);}
        
        
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,50,0,0);
        c.anchor = GridBagConstraints.CENTER;
        add(tableSP,c);
        
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,20,0);
        c.anchor = GridBagConstraints.SOUTH;
        add(whichGrade,c);
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,3,100);
        c.anchor = GridBagConstraints.SOUTH;
        add(gradeLabel,c);
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,50,0,0);
        c.anchor = GridBagConstraints.SOUTH;
        add(gradeScore,c);
        
        
        c.gridx = 1; 
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        c.insets = new Insets(0,0,0,250);
        c.anchor = GridBagConstraints.SOUTHEAST;
        add(new JButton(new AbstractAction("Submit") {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (table.getSelectedRow() != -1) {
                    
                    gradeScore.setText(null);
                    whichGrade.setSelectedItem("Initial Grade");
                   
                }
            }
        }),c);
        
    }
}
