package informationsystem.useraccount;
import informationsystem.data.*;

public class Student{
    private String surname;
    private String forename;
    private Degree degree;
    private int registNum;
    private String email;
    private String tutorName;
    private boolean registered;
    private String username;
    //mr,ms --->(1,2)
    public String title;

    public Student(String title, String surname, String tutor, String forename) {
        this.title = title;
        this.surname = surname;
        this.forename = forename;
        this.tutorName = tutor;
    }
    
    public Student(int num) {
        registNum = num;
    }
    
    public String getStudentTitle() {
        return title;
    }

    public String getStudentSurname() {
        return surname;
    }

    public String getStudentForename() {
        return forename;
    }

    public Degree getStudentDegree() {
        return degree;
    }

    public int getRegistNum() {
        return registNum;
    }

    public String getStudentEmail() {
        return email;
    }

    public String getStudentTutorName() {
        return tutorName;
    }

    public boolean getRegistOrNot() {
        return registered;
    }
    
    public String getUsername() {
        return username;
    }

}
