package informationsystem.useraccount.student;

public class RegistrationConfirm {
    private boolean registrationConfirm;

}
