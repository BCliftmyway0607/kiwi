package informationsystem.useraccount.student;

public class PeriodOfStudy {
    private char label;
    private int startDate;
    private int endDate;
    //1,2,3,4
    private int periodOfStudy;
    public PeriodOfStudy(int periodOfStudy){
        this.periodOfStudy = periodOfStudy;

    }
    public int getPeriodOfStudy(){
        return periodOfStudy;
    }


}
