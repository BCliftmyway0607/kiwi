package informationsystem.useraccount.student;

public class ModuleSignUp {
    private int totalCredit;
}
