package informationsystem.useraccount.student;

public class Grade {


    private double moduleGrade;
    private double firstGrade;
    private double secondGrade ;
    private double repeatYearGrade = 0;
    
    
    public Grade(double firstGrade, double secondGrade, double moduleGrade) {
        this.firstGrade = firstGrade;
        this.secondGrade = secondGrade;
        this.moduleGrade = moduleGrade;
    }
    
    
    public double lv1tolv3calcPassMark() {
        double calculatedGrade = 0;
        while(firstGrade>=0&&firstGrade<=100)
            if(firstGrade>40){
                calculatedGrade = firstGrade;
            }else{
                calculatedGrade = (secondGrade);
                if(secondGrade>40){
                    calculatedGrade = 40;
                }else {
                    return -1;//stand in for failed
                }

            }
        this.moduleGrade = calculatedGrade;
        return moduleGrade;
    }
        
    public double lv4calcPassMark() {
        double calculatedGrade = 0;
        while(firstGrade>=0&&firstGrade<=100)
            if(firstGrade>50){
                calculatedGrade= firstGrade;
            }else {
                calculatedGrade= (secondGrade);
                if(secondGrade>50){
                    calculatedGrade = 50;
                }else {
                    return -1;//stand in for failed
                }
            }
        this.moduleGrade = calculatedGrade;
        return moduleGrade;
    }

    public double getFirstGrade(){return this.firstGrade;}
    public double getSecondGrade(){return this.secondGrade;}
    public double getRepeatYearGrade(){return this.repeatYearGrade;}
    
}