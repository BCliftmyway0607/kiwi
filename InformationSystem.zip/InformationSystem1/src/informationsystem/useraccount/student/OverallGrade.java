package informationsystem.useraccount.student;

import informationsystem.useraccount.Student;

import java.util.Scanner;

public class OverallGrade extends Grade {
    public OverallGrade(double firstGrade, double secondGrade, double moduleGrade) {
        super(firstGrade, secondGrade, moduleGrade);
    }

    private double firstGrade;
    private double secondGrade = 0;
    private double repeatYearGrade = 0;
    private double capPassMark;
    private double moduleGrade;




    //passmark for lv1-lv3
    public double calcPassMarklv1to3() {
        while(firstGrade>=0&&firstGrade<=100)
            if(firstGrade>40){
                double moduleGrade= firstGrade;
            }else{
                double moduleGrade= (secondGrade);
                if(secondGrade>40){
                    moduleGrade = capPassMark;
                }else {
                    System.out.println("failed");
                }

            }
        return moduleGrade;
    }
    //passmark for lv4
    public double calcPassMarklv4() {
        while(firstGrade>=0&&firstGrade<=100)
            if(firstGrade>50){
                double moduleGrade= firstGrade;
            }else {
                double moduleGrade= (secondGrade);
                if(secondGrade>50){
                    moduleGrade = capPassMark;;
                }else {
                    System.out.println("failed");
                }
            }
        return moduleGrade;
    }
    public double calcMeanScore() {
        //get meanGrades
        int n = 0;
        double moduleGrades[] = new double[n];
        int i ;
        double total = 0;

        Scanner scanner = new Scanner(System.in);
        for(i=0;i<n;i++){
            moduleGrades[n]=scanner.nextInt();
            total = total + moduleGrades[i];
        }
        scanner.close();
        double meanGrade = total/n;

        return meanGrade;

        }
    }
