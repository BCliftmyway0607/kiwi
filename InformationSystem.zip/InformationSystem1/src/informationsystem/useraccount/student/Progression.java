package informationsystem.useraccount.student;

public class Progression extends OverallGrade {
    private int numFailed;
    private boolean outCome;

    public Progression(double firstGrade, double secondGrade, double moduleGrade) {
        super(firstGrade, secondGrade, moduleGrade);
    }


}
