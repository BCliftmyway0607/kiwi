package informationsystem.useraccount;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class User {


    public String userAccount;
    public String userPassword;
    
    // Admin, Registrar, Teacher, Student -> (1,2,3,4)
    public int role;


    public User(String name, String password, int userRole) {
        this.userAccount = name;
        this.userPassword = password;
        this.role = userRole;
    }
    
    public User(String name, int role) {
        this.userAccount = name;
        this.role = role;
    }
    
    public User(String name, String password) {
        this.userAccount = name;
        this.userPassword = password;
    }
    // The functions below involve collecting and changing database info
    
    public User(String name) {
        this.userAccount = name;
    }
    
    public String getUserAccountName() {
        return userAccount;
    }

    public String getUserAccountPassword() {
        return userPassword;
    }
    
    public int getUserAccountRole() {
        return role;
    }


}
