package informationsystem.data;

public class Module {
    private String name;
    private String code;
    private int credit;
    // AUTUMN, SPRING, SUMMER, YEAR ->(0,1,2,3)
    public int season;
    public Boolean core;
    
    public Module(String moduleName, String moduleCode, int moduleCredit, int moduleSeason) {
        this.name = moduleName;
        this.code = moduleCode;
        this.credit = moduleCredit;
        this.season = moduleSeason;
    }
    
    public Module(String moduleCode){
        this.code = moduleCode;
    }
    
    public String getName() {
        return this.name;
    }
    public String getModuleCode() {
        return this.code;
    }
    public int getModuleCredit() {
        return this.credit;
    }
    public int getModuleSeason(){return this.season;}
    
    public Boolean getCore() {
        return this.core;
    }
    
    public int getSeason() {
        return this.season;
    }
    
    // Base on number, return String year
    public String getSeasonString() {
        switch(this.season) {
        case 0: return "Autumn";
        case 1: return "Spring";
        case 2: return "Autumn";
        }
        return "Year";
    }

}
