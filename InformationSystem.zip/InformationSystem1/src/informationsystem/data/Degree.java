package informationsystem.data;

public class Degree {
    private String degreeName;
    private Boolean yearInIndustry;
    private String leadCode;
    private int level;
    private String degreeFullCode;
    
    public Degree(String degreeName, String leadCode, Boolean yearInIndusty, int level) {
        this.degreeName = degreeName;
        this.yearInIndustry = yearInIndusty;
        this.leadCode = leadCode;
        this.level = level;
    }
    
  
    public Degree(String degreeCode) {
        this.degreeFullCode = degreeCode;
    }

    public String getName() {
        return this.degreeName;
    }

    public String getleadCode() {
        return this.leadCode;
    }
    
    public Boolean getyearInIndustry() {
        return this.yearInIndustry;
    }
    
    public int getLevel() {
        return this.level;
    }
    
    public String getDegreeFullCode() {
        return this.degreeFullCode;
    }
}
