package informationsystem.data;

public class Level {

    private char code;
    private boolean core;
    //1,2,3,4 ->[0,1,2,3]
    public int level;
    
    public Level(int name, char levelCode, boolean levelCore) {
        this.level = name;
        this.code = levelCode;
        this.core = levelCore;
    }
    public void setLevelName(int name) {
        level = name;
    }
    public void setLevelCode(char levelCode) {
        code = levelCode;
    }
    public void setLevelCore(boolean levelCore) {
        core = levelCore;
    }
    public int getLevelName() {
        return this.level;
    }
    public char getLevelCode() {
        return this.code;
    }
    public boolean getLevelCore() {
        return this.core;
    }
}
