package informationsystem.data;

public class Department {
    private String name;
    private String code;

    public Department(String departmentName, String departmentCode) {
        this.name = departmentName;
        this.code = departmentCode;
    }
    
    public void setName(String departmentName) {
        name = departmentName;
    }
    public void setCode(String departmentCode) {
        code = departmentCode;
    }
    public String getName() {
        return this.name;
    }
    public String getCode() {
        return this.code;
    }
}
