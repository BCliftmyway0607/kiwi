import informationsystem.sql.*;
import informationsystem.useraccount.*;

public class main {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        RegistrarStatement ad = new RegistrarStatement(0);
        ad.getAllStudent();
        
        Student jeff = new Student("Mr","Kied","Nitri","Kloff");
        TeacherStatement lol = new TeacherStatement(jeff);
        System.out.println(lol.getStudentGrades());
    }

}
